import React from 'react';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { InvestigativeNewspaperLens } from './InvestigativeNewspaperLens';
import { Headphones, Rss, ShieldCheck, Sparkles, Layers, Search } from 'lucide-react';

export interface SplineHeroProps {
  onOpenAddFeed: () => void;
  onExploreDiscovery: () => void;
}

export const SplineHero: React.FC<SplineHeroProps> = ({ onOpenAddFeed, onExploreDiscovery }) => {
  return (
    <section className="relative w-full rounded-3xl border-2 border-theme-border bg-gradient-to-br from-theme-surface via-theme-surface to-theme-elevated/80 backdrop-blur-2xl overflow-hidden shadow-xl mb-8 transition-colors duration-200">
      {/* Decorative ambient radial gradients */}
      <div className="absolute -top-32 -left-32 h-72 w-72 rounded-full bg-amber-500/10 blur-[120px] pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 h-72 w-72 rounded-full bg-emerald-500/10 blur-[120px] pointer-events-none" />

      <div className="grid grid-cols-1 lg:grid-cols-12 items-center relative z-10 min-h-[360px]">
        {/* Left Column: Hero Copy */}
        <div className="lg:col-span-7 p-6 sm:p-8 lg:p-10 flex flex-col justify-center space-y-5">
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="amber" className="gap-1.5 py-1 px-3 font-serif font-bold">
              <Rss className="h-3.5 w-3.5" />
              <span>Offline-First RSS Gazette</span>
            </Badge>
            <Badge variant="emerald" className="gap-1.5 py-1 px-3 font-serif font-bold">
              <Headphones className="h-3.5 w-3.5" />
              <span>Synced Paragraph Narration</span>
            </Badge>
          </div>

          <div className="space-y-2">
            <h1 className="font-editorial text-2xl sm:text-3xl lg:text-4xl font-black text-theme-heading tracking-tight leading-tight">
              Read and Listen to the Web with{' '}
              <span className="text-amber-500 underline decoration-amber-500/30 underline-offset-4">
                Absolute Privacy
              </span>
            </h1>
            <p className="font-serif text-xs sm:text-sm text-theme-body leading-relaxed max-w-xl">
              Zero cloud tracking. Feeds are parsed in-browser, stored in <strong>IndexedDB</strong>, 
              sanitized with <strong>DOMPurify</strong>, and narrated aloud with interactive paragraph-synchronized speech.
            </p>
          </div>

          {/* Quick CTA Actions */}
          <div className="flex flex-wrap items-center gap-3 pt-1">
            <Button
              variant="amber"
              size="md"
              onClick={onOpenAddFeed}
              className="gap-2 shadow-amber-500/20 shadow-md font-serif font-bold text-xs"
            >
              <Rss className="h-4 w-4" />
              <span>Subscribe to Feed</span>
            </Button>

            <Button
              variant="glass"
              size="md"
              onClick={onExploreDiscovery}
              className="gap-2 font-serif text-xs font-bold"
            >
              <Sparkles className="h-4 w-4 text-amber-500" />
              <span>Explore Co-Feeds</span>
            </Button>
          </div>

          {/* Tech Badges */}
          <div className="grid grid-cols-3 gap-3 pt-3 border-t border-theme-subtle text-xs">
            <div>
              <div className="font-bold text-theme-heading font-mono flex items-center gap-1">
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
                <span>SSRF-Safe</span>
              </div>
              <p className="text-[11px] text-theme-muted font-serif">Relayed via Proxy</p>
            </div>
            <div>
              <div className="font-bold text-theme-heading font-mono flex items-center gap-1">
                <Layers className="h-3.5 w-3.5 text-amber-500" />
                <span>IndexedDB</span>
              </div>
              <p className="text-[11px] text-theme-muted font-serif">Local cache</p>
            </div>
            <div>
              <div className="font-bold text-theme-heading font-mono flex items-center gap-1">
                <Headphones className="h-3.5 w-3.5 text-emerald-500" />
                <span>Web Speech</span>
              </div>
              <p className="text-[11px] text-theme-muted font-serif">Zero-latency TTS</p>
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Investigative Newspaper & Moving Magnifying Glass */}
        <div className="lg:col-span-5 h-full min-h-[300px] relative flex items-center justify-center p-4 sm:p-6 overflow-hidden">
          <InvestigativeNewspaperLens />
        </div>
      </div>
    </section>
  );
};
