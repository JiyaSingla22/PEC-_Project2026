import React from 'react';
import { Article } from '../../types';
import { useFeeds } from '../../context/FeedContext';
import { useAudio } from '../../context/AudioContext';
import { timeAgo } from '../../lib/utils';
import {
  Headphones,
  Bookmark,
  Clock,
  CheckCircle2,
  ExternalLink,
  Plus,
} from 'lucide-react';

export interface ArticleCardProps {
  article: Article;
  featured?: boolean;
}

export const ArticleCard: React.FC<ArticleCardProps> = ({ article, featured = false }) => {
  const { setReadingArticle, markAsRead, toggleBookmark } = useFeeds();
  const { currentArticle, playbackState, playArticle, togglePlayPause, addToQueue } = useAudio();

  const isCurrentAudio = currentArticle?.id === article.id;
  const isAudioPlaying = isCurrentAudio && playbackState === 'playing';

  const handleOpenReader = () => {
    setReadingArticle(article);
  };

  const handleToggleTTS = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isCurrentAudio) {
      togglePlayPause();
    } else {
      playArticle(article);
    }
  };

  const handleQueue = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToQueue(article);
  };

  const handleBookmark = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleBookmark(article.id);
  };

  const handleMarkRead = (e: React.MouseEvent) => {
    e.stopPropagation();
    markAsRead(article.id);
  };

  return (
    <article
      onClick={handleOpenReader}
      className={`group relative rounded-2xl transition-all duration-200 p-5 sm:p-6 cursor-pointer flex flex-col justify-between space-y-4 select-none ${
        featured
          ? 'border-2 border-theme-border bg-theme-surface shadow-md hover:border-amber-500/60 hover:shadow-lg'
          : article.isRead
          ? 'border border-theme-border/70 bg-theme-surface/70 hover:bg-theme-surface hover:border-theme-border opacity-90 hover:opacity-100 shadow-xs'
          : 'border border-theme-border bg-theme-surface hover:border-amber-500/50 shadow-xs hover:shadow-md'
      }`}
    >
      {/* Top Meta Header: Newspaper Kicker & Timestamp */}
      <div className="flex items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2 min-w-0">
          {/* Unread Amber Indicator dot */}
          {!article.isRead ? (
            <span className="h-2 w-2 rounded-full bg-amber-500 shrink-0" title="Unread story" />
          ) : (
            <span className="h-2 w-2 rounded-full bg-theme-muted/40 shrink-0" title="Read" />
          )}
          <span className="font-mono text-[11px] font-bold tracking-widest uppercase text-amber-600 dark:text-amber-400 truncate max-w-[150px] sm:max-w-[220px]">
            {article.feedTitle}
          </span>
          <span className="text-theme-muted">•</span>
          <span className="text-theme-muted shrink-0 flex items-center gap-1 font-serif text-[11px]">
            <Clock className="h-3 w-3" />
            {article.estimatedReadMinutes}m read
          </span>
        </div>

        <div className="flex items-center gap-1 shrink-0 text-theme-muted font-serif text-xs italic">
          <span>{timeAgo(article.publishedAt)}</span>
        </div>
      </div>

      {/* Main Title & Excerpt (Crystal Clear Newspaper Editorial Styling) */}
      <div className="space-y-2">
        <h3
          className={`font-editorial font-bold tracking-tight leading-snug transition-colors line-clamp-2 ${
            featured ? 'text-xl sm:text-2xl text-theme-heading' : 'text-base sm:text-lg text-theme-heading'
          } group-hover:text-amber-600 dark:group-hover:text-amber-400`}
        >
          {article.title}
        </h3>

        {article.excerpt && (
          <p
            className={`font-serif text-xs sm:text-sm text-theme-body leading-relaxed ${
              featured ? 'line-clamp-3 italic' : 'line-clamp-2'
            }`}
          >
            {article.excerpt}
          </p>
        )}

        {article.author && (
          <p className="text-[11px] text-theme-muted font-serif italic pt-0.5">
            By {article.author}
          </p>
        )}
      </div>

      {/* Bottom Action Toolbar */}
      <div className="flex items-center justify-between pt-3 border-t border-theme-subtle text-xs">
        {/* Listen to Article TTS Trigger */}
        <button
          onClick={handleToggleTTS}
          aria-label={isAudioPlaying ? 'Pause narration' : 'Listen to story aloud'}
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl font-serif text-xs font-bold transition-all duration-150 min-h-[38px] ${
            isAudioPlaying
              ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/25'
              : 'bg-theme-elevated hover:bg-amber-500/15 border border-theme-border text-theme-heading hover:border-amber-500/40'
          }`}
        >
          {isAudioPlaying ? (
            <>
              <div className="flex items-end justify-center gap-0.5 h-3.5 w-3.5">
                <span className="w-0.5 bg-current rounded-full animate-equalizer-1" />
                <span className="w-0.5 bg-current rounded-full animate-equalizer-2" />
                <span className="w-0.5 bg-current rounded-full animate-equalizer-3" />
              </div>
              <span>Playing Audio</span>
            </>
          ) : (
            <>
              <Headphones className="h-3.5 w-3.5 text-amber-500" />
              <span>Listen ({article.estimatedReadMinutes}m)</span>
            </>
          )}
        </button>

        {/* Action icons with clear hit-targets */}
        <div className="flex items-center gap-1 text-theme-muted">
          <button
            onClick={handleQueue}
            title="Add to Audio Play Later Queue"
            className="p-2 rounded-xl hover:bg-theme-elevated hover:text-theme-heading transition-colors"
          >
            <Plus className="h-4 w-4" />
          </button>

          <button
            onClick={handleBookmark}
            title={article.isBookmarked ? 'Remove Bookmark' : 'Bookmark story'}
            className={`p-2 rounded-xl transition-colors ${
              article.isBookmarked
                ? 'text-amber-500 bg-amber-500/10'
                : 'hover:bg-theme-elevated hover:text-theme-heading'
            }`}
          >
            <Bookmark className={`h-4 w-4 ${article.isBookmarked ? 'fill-current' : ''}`} />
          </button>

          {!article.isRead && (
            <button
              onClick={handleMarkRead}
              title="Mark as Read"
              className="p-2 rounded-xl hover:bg-theme-elevated hover:text-emerald-500 transition-colors"
            >
              <CheckCircle2 className="h-4 w-4" />
            </button>
          )}

          <a
            href={article.link}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            title="Open original publication"
            className="p-2 rounded-xl hover:bg-theme-elevated hover:text-theme-heading transition-colors"
          >
            <ExternalLink className="h-4 w-4" />
          </a>
        </div>
      </div>
    </article>
  );
};
