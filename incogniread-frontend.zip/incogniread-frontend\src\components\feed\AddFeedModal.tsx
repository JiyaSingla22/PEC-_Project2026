import React, { useState } from 'react';
import { Dialog } from '../ui/dialog';
import { Input } from '../ui/input';
import { Button } from '../ui/button';
import { useFeeds } from '../../context/FeedContext';
import { Plus, Rss, Folder, AlertCircle, Sparkles } from 'lucide-react';

export interface AddFeedModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PRESET_FEEDS = [
  { url: 'https://overreacted.io/rss.xml', title: 'Overreacted (Dan Abramov)', folder: 'Engineering & AI' },
  { url: 'https://simonwillison.net/atom/entries/', title: 'Simon Willison’s Weblog', folder: 'Engineering & AI' },
  { url: 'https://news.ycombinator.com/rss', title: 'Hacker News Frontpage', folder: 'Tech Journalism' },
  { url: 'https://www.theverge.com/rss/index.xml', title: 'The Verge', folder: 'Tech Journalism' },
  { url: 'https://hacks.mozilla.org/feed/', title: 'Mozilla Hacks', folder: 'Web Development' },
];

export const AddFeedModal: React.FC<AddFeedModalProps> = ({ isOpen, onClose }) => {
  const { addNewFeed, folders } = useFeeds();
  const [url, setUrl] = useState('');
  const [folder, setFolder] = useState('Engineering & AI');
  const [customFolder, setCustomFolder] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;

    setIsLoading(true);
    setErrorMsg(null);

    const targetFolder = customFolder.trim() || folder || 'General';

    try {
      await addNewFeed(url.trim(), targetFolder);
      setUrl('');
      setCustomFolder('');
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to discover or parse feed.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectPreset = (presetUrl: string, presetFolder: string) => {
    setUrl(presetUrl);
    setFolder(presetFolder);
  };

  return (
    <Dialog
      isOpen={isOpen}
      onClose={onClose}
      title={
        <div className="flex items-center gap-2">
          <Rss className="h-5 w-5 text-amber-500" />
          <span className="font-editorial">Subscribe to New Feed</span>
        </div>
      }
      description="Enter a website URL or direct RSS/Atom XML link. IncogniRead will autodiscover the feed and parse it safely."
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {errorMsg && (
          <div className="flex items-start gap-2.5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-500 text-xs leading-relaxed break-words">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span className="flex-1">{errorMsg}</span>
          </div>
        )}

        <div>
          <label className="block text-xs font-serif font-bold text-theme-heading mb-1.5">
            Website or Feed URL
          </label>
          <Input
            type="text"
            placeholder="e.g. overreacted.io or https://example.com/feed"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            icon={<Rss className="h-4 w-4" />}
            required
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-serif font-bold text-theme-heading mb-1.5">
              Select Department / Folder
            </label>
            <select
              value={folder}
              onChange={(e) => setFolder(e.target.value)}
              className="w-full h-11 min-h-[44px] rounded-xl border border-theme-border bg-theme-surface text-sm text-theme-heading px-3 focus:outline-none focus:border-amber-500 font-serif"
            >
              {folders.map((f) => (
                <option key={f.id} value={f.name}>
                  {f.name}
                </option>
              ))}
              <option value="New Folder">+ Create New Folder...</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-serif font-bold text-theme-heading mb-1.5">
              Custom Folder Name (Optional)
            </label>
            <Input
              type="text"
              placeholder="e.g. Machine Learning"
              value={customFolder}
              onChange={(e) => setCustomFolder(e.target.value)}
              icon={<Folder className="h-4 w-4" />}
            />
          </div>
        </div>

        {/* Quick Presets */}
        <div className="space-y-2 pt-2 border-t border-theme-subtle">
          <span className="text-[11px] font-bold uppercase tracking-wider text-theme-muted flex items-center gap-1 font-mono">
            <Sparkles className="h-3.5 w-3.5 text-amber-500" />
            Curated Press Subscriptions:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {PRESET_FEEDS.map((preset) => (
              <button
                type="button"
                key={preset.url}
                onClick={() => handleSelectPreset(preset.url, preset.folder)}
                className="px-2.5 py-1 text-xs rounded-xl bg-theme-surface border border-theme-border text-theme-heading hover:border-amber-500/50 transition-colors font-serif"
              >
                {preset.title}
              </button>
            ))}
          </div>
        </div>

        <div className="pt-2 flex justify-end gap-2">
          <Button type="button" variant="ghost" onClick={onClose} className="font-serif">
            Cancel
          </Button>
          <Button type="submit" variant="amber" isLoading={isLoading} className="gap-2 font-serif font-bold">
            <Plus className="h-4 w-4" />
            <span>Discover & Subscribe</span>
          </Button>
        </div>
      </form>
    </Dialog>
  );
};
