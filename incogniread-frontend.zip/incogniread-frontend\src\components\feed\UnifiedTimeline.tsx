import React, { useMemo, useState } from 'react';
import { useFeeds } from '../../context/FeedContext';
import { ArticleCard } from './ArticleCard';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import {
  Rss,
  CheckCheck,
  RefreshCw,
  Search,
  Bookmark,
  Inbox,
  Flame,
  LayoutGrid,
  List,
  Newspaper,
  Calendar,
} from 'lucide-react';

export const UnifiedTimeline: React.FC = () => {
  const {
    feeds,
    articles,
    activeFilter,
    activeFolder,
    searchQuery,
    isSyncing,
    syncProgress,
    setActiveFilter,
    markAllAsRead,
    syncAllFeeds,
  } = useFeeds();

  const [layoutMode, setLayoutMode] = useState<'broadsheet' | 'stream'>('broadsheet');

  // Filter articles according to active filter, folder, and search input
  const filteredArticles = useMemo(() => {
    return articles.filter((art) => {
      // 1. Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = art.title.toLowerCase().includes(q);
        const matchesExcerpt = art.excerpt.toLowerCase().includes(q);
        const matchesFeed = art.feedTitle.toLowerCase().includes(q);
        if (!matchesTitle && !matchesExcerpt && !matchesFeed) return false;
      }

      // 2. Folder Filter
      if (activeFolder !== 'all') {
        const parentFeed = feeds.find((f) => f.id === art.feedId);
        if (parentFeed?.folder !== activeFolder) return false;
      }

      // 3. Tab Filter (all | unread | bookmarks | feedId)
      if (activeFilter === 'unread') return !art.isRead;
      if (activeFilter === 'bookmarks') return art.isBookmarked;
      if (activeFilter !== 'all') return art.feedId === activeFilter;

      return true;
    });
  }, [articles, feeds, activeFilter, activeFolder, searchQuery]);

  const activeFeedObj = feeds.find((f) => f.id === activeFilter);
  const unreadTotal = articles.filter((a) => !a.isRead).length;

  // Format today's date in classic newspaper format
  const todayDateString = useMemo(() => {
    const d = new Date();
    return d.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).toUpperCase();
  }, []);

  const [leadArticle, ...restArticles] = filteredArticles;

  return (
    <div className="space-y-6">
      {/* Newspaper Grand Masthead Banner */}
      <section className="pt-2 pb-4 text-center select-none border-b-2 border-theme-rule">
        {/* Top Dateline Bar */}
        <div className="flex flex-wrap items-center justify-between text-[11px] font-mono uppercase tracking-wider text-theme-muted pb-2 border-b border-theme-subtle gap-2">
          <span className="flex items-center gap-1.5 font-bold">
            <Calendar className="h-3 w-3 text-amber-500" />
            <span>{todayDateString}</span>
          </span>
          <span className="hidden sm:inline italic font-serif">
            “All the feeds fit to read, parsed with private offline fidelity”
          </span>
          <span className="font-bold text-amber-600 dark:text-amber-400">
            VOL. CLXXV … No. 59,820 • CITY EDITION
          </span>
        </div>

        {/* Masthead Title */}
        <div className="py-4 sm:py-6">
          <h1 className="font-masthead text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-theme-heading uppercase">
            The IncogniRead Dispatch
          </h1>
          <div className="flex items-center justify-center gap-3 pt-2 text-amber-500 text-xs">
            <span className="h-px w-12 bg-theme-border" />
            <span>❖</span>
            <span className="font-serif italic text-theme-muted tracking-wide text-xs sm:text-sm">
              International Reader of Record • Paragraph-Synced Speech Narration
            </span>
            <span>❖</span>
            <span className="h-px w-12 bg-theme-border" />
          </div>
        </div>

        {/* Newspaper Sub-Header / Section Bar */}
        <div className="pt-2 border-t border-theme-subtle flex flex-wrap items-center justify-between text-xs gap-3">
          <div className="flex items-center gap-2">
            <span className="font-editorial font-bold text-theme-heading text-sm">
              {activeFilter === 'all'
                ? activeFolder === 'all'
                  ? 'Main Broadsheet'
                  : `Department: ${activeFolder}`
                : activeFilter === 'unread'
                ? 'Unread Dispatches'
                : activeFilter === 'bookmarks'
                ? 'Archived Clippings'
                : activeFeedObj?.title || 'Feed Articles'}
            </span>
            <Badge variant="amber" className="font-mono text-[11px]">
              {filteredArticles.length} stories
            </Badge>
          </div>

          <div className="flex items-center gap-2">
            {/* Broadsheet vs Stream Layout Toggle */}
            <div className="flex items-center p-0.5 rounded-xl border border-theme-border bg-theme-surface">
              <button
                onClick={() => setLayoutMode('broadsheet')}
                aria-label="Broadsheet layout"
                title="Broadsheet newspaper layout"
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-serif transition-colors ${
                  layoutMode === 'broadsheet'
                    ? 'bg-amber-500/20 text-amber-600 dark:text-amber-400 font-bold'
                    : 'text-theme-muted hover:text-theme-heading'
                }`}
              >
                <Newspaper className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Broadsheet</span>
              </button>

              <button
                onClick={() => setLayoutMode('stream')}
                aria-label="Stream layout"
                title="Compact stream layout"
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-serif transition-colors ${
                  layoutMode === 'stream'
                    ? 'bg-amber-500/20 text-amber-600 dark:text-amber-400 font-bold'
                    : 'text-theme-muted hover:text-theme-heading'
                }`}
              >
                <List className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Stream</span>
              </button>
            </div>

            {/* Sync Feeds Button */}
            <Button
              variant="glass"
              size="sm"
              onClick={syncAllFeeds}
              isLoading={isSyncing}
              className="text-xs gap-1.5 min-h-[36px] font-serif"
              title="Refresh feeds via proxy"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${isSyncing ? 'animate-spin text-amber-500' : ''}`} />
              <span className="hidden sm:inline">{isSyncing ? `Syncing (${syncProgress.current}/${syncProgress.total})` : 'Sync Wire'}</span>
            </Button>

            {/* Mark All Read */}
            {unreadTotal > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={markAllAsRead}
                className="text-xs gap-1.5 text-theme-muted hover:text-theme-heading min-h-[36px] font-serif"
                title="Mark all current articles as read"
              >
                <CheckCheck className="h-3.5 w-3.5 text-emerald-500" />
                <span className="hidden sm:inline">Mark All Read</span>
              </Button>
            )}
          </div>
        </div>
      </section>

      {/* Quick Filter Section Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        {[
          { id: 'all', label: 'All Dispatches', count: articles.length },
          { id: 'unread', label: 'Unread', count: unreadTotal },
          { id: 'bookmarks', label: 'Bookmarked', count: articles.filter((a) => a.isBookmarked).length },
        ].map((tab) => {
          const isActive = activeFilter === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveFilter(tab.id)}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-serif font-semibold whitespace-nowrap transition-all min-h-[36px] ${
                isActive
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'bg-theme-surface hover:bg-theme-elevated text-theme-muted hover:text-theme-heading border border-theme-border'
              }`}
            >
              <span>{tab.label}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                  isActive ? 'bg-slate-950/20 text-slate-950 font-bold' : 'bg-theme-elevated text-theme-muted'
                }`}
              >
                {tab.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Feed Cards Grid / Stream */}
      {filteredArticles.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-theme-border p-12 text-center space-y-3 bg-theme-surface/30">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-theme-elevated text-amber-500 mx-auto">
            <Inbox className="h-6 w-6" />
          </div>
          <h4 className="text-base font-editorial font-bold text-theme-heading">
            No dispatches match your filter
          </h4>
          <p className="text-xs text-theme-muted max-w-sm mx-auto font-serif">
            {searchQuery
              ? `No articles found matching “${searchQuery}”. Try a different keyword.`
              : 'You have read all articles or haven’t added any subscriptions to this view.'}
          </p>
          {activeFilter !== 'all' && (
            <Button variant="outline" size="sm" onClick={() => setActiveFilter('all')} className="font-serif">
              Reset Filter to All
            </Button>
          )}
        </div>
      ) : layoutMode === 'broadsheet' && leadArticle ? (
        /* Broadsheet Editorial Newspaper Layout */
        <div className="space-y-5">
          {/* Featured Lead Story */}
          <ArticleCard article={leadArticle} featured={true} />

          {/* 2-Column Broadsheet Grid for the remaining articles */}
          {restArticles.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              {restArticles.map((article) => (
                <ArticleCard key={article.id} article={article} />
              ))}
            </div>
          )}
        </div>
      ) : (
        /* Stream Newspaper Layout */
        <div className="space-y-4">
          {filteredArticles.map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
      )}
    </div>
  );
};
