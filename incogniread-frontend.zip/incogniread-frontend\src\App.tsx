import React, { useState } from 'react';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { RightPanel } from './components/layout/RightPanel';
import { MobileNav } from './components/layout/MobileNav';
import { SplineHero } from './components/feed/SplineHero';
import { UnifiedTimeline } from './components/feed/UnifiedTimeline';
import { ReaderView } from './components/feed/ReaderView';
import { FloatingAudioPlayer } from './components/audio/FloatingAudioPlayer';
import { AddFeedModal } from './components/feed/AddFeedModal';
import { OPMLModal } from './components/discovery/OPMLModal';
import { AnonymousDiscovery } from './components/discovery/AnonymousDiscovery';
import { Dialog } from './components/ui/dialog';
import { useFeeds } from './context/FeedContext';

export const App: React.FC = () => {
  const { activeFilter, activeFolder } = useFeeds();
  const [isAddFeedOpen, setIsAddFeedOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isDiscoveryOpen, setIsDiscoveryOpen] = useState(false);
  const [isOPMLOpen, setIsOPMLOpen] = useState(false);

  return (
    <div className="min-h-screen bg-theme-base text-theme-body flex flex-col font-sans selection:bg-amber-500/20 selection:text-amber-500 transition-colors duration-200">
      {/* Background ambient lighting glows */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden opacity-30 dark:opacity-100 transition-opacity">
        <div className="absolute -top-40 -left-40 h-[600px] w-[600px] rounded-full bg-amber-500/10 blur-[150px]" />
        <div className="absolute top-1/2 -right-40 h-[650px] w-[650px] rounded-full bg-emerald-500/5 blur-[160px]" />
        <div className="absolute -bottom-40 left-1/3 h-[500px] w-[500px] rounded-full bg-orange-500/10 blur-[140px]" />
      </div>

      {/* Top Navbar */}
      <Navbar
        onOpenAddFeed={() => setIsAddFeedOpen(true)}
        onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
        onOpenDiscovery={() => setIsDiscoveryOpen(true)}
        onOpenOPML={() => setIsOPMLOpen(true)}
      />

      {/* Mobile Drawer Navigation */}
      <MobileNav
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
        onOpenAddFeed={() => setIsAddFeedOpen(true)}
        onOpenDiscovery={() => setIsDiscoveryOpen(true)}
        onOpenOPML={() => setIsOPMLOpen(true)}
      />

      {/* 3-Column Responsive Shell */}
      <div className="relative z-10 flex-1 flex w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Left Column: Subscriptions & Folders Sidebar (Desktop >= 1024px) */}
        <Sidebar
          onOpenAddFeed={() => setIsAddFeedOpen(true)}
          onOpenDiscovery={() => setIsDiscoveryOpen(true)}
          onOpenOPML={() => setIsOPMLOpen(true)}
        />

        {/* Central Column: Unified Timeline / Reading Feed */}
        <main className="flex-1 min-w-0 px-2 sm:px-6 py-6 pb-32">
          {/* Hero only on general 'all' view */}
          {activeFilter === 'all' && activeFolder === 'all' && (
            <SplineHero
              onOpenAddFeed={() => setIsAddFeedOpen(true)}
              onExploreDiscovery={() => setIsDiscoveryOpen(true)}
            />
          )}

          <UnifiedTimeline />
        </main>

        {/* Right Column: Audio Queue & Anonymous Discovery (Desktop >= 1280px) */}
        <RightPanel />
      </div>

      {/* Persistent Floating Audio Player (Sticky bottom) */}
      <FloatingAudioPlayer />

      {/* Distraction-Free Reader View */}
      <ReaderView />

      {/* Add Feed Modal */}
      <AddFeedModal
        isOpen={isAddFeedOpen}
        onClose={() => setIsAddFeedOpen(false)}
      />

      {/* OPML Import / Export Modal (PS-003 Bonus) */}
      <OPMLModal
        isOpen={isOPMLOpen}
        onClose={() => setIsOPMLOpen(false)}
      />

      {/* Anonymous Discovery Modal */}
      <Dialog
        isOpen={isDiscoveryOpen}
        onClose={() => setIsDiscoveryOpen(false)}
        maxWidth="xl"
        title="Anonymous Co-Subscription Discovery"
        description="Collective recommendation engine with transparent reasoning, co-subscription graph view, and zero accounts."
      >
        <AnonymousDiscovery />
      </Dialog>
    </div>
  );
};

export default App;
