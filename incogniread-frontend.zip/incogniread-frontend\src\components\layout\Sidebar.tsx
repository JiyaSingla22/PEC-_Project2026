import React, { useState } from 'react';
import { useFeeds } from '../../context/FeedContext';
import { Badge } from '../ui/badge';
import {
  Rss,
  Folder as FolderIcon,
  ChevronDown,
  ChevronRight,
  Inbox,
  Bookmark,
  Sparkles,
  Trash2,
  Plus,
  Compass,
  FileCode,
} from 'lucide-react';

export interface SidebarProps {
  onOpenAddFeed: () => void;
  onOpenDiscovery: () => void;
  onOpenOPML: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  onOpenAddFeed,
  onOpenDiscovery,
  onOpenOPML,
}) => {
  const {
    feeds,
    articles,
    folders,
    activeFilter,
    activeFolder,
    setActiveFilter,
    setActiveFolder,
    deleteFeed,
  } = useFeeds();

  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({
    'Engineering & AI': true,
    'Tech Journalism': true,
    'Web Development': true,
  });

  const toggleFolder = (folderName: string) => {
    setExpandedFolders((prev) => ({ ...prev, [folderName]: !prev[folderName] }));
  };

  const unreadTotal = articles.filter((a) => !a.isRead).length;

  return (
    <aside className="hidden lg:flex w-60 shrink-0 flex-col justify-between border-r border-theme-border bg-theme-surface/60 backdrop-blur-xl p-4 min-h-[calc(100vh-4rem)] sticky top-16 overflow-y-auto transition-colors duration-200">
      <div className="space-y-6">
        {/* Core Views Filter */}
        <div className="space-y-1">
          <p className="px-3 text-[10px] font-mono font-bold uppercase tracking-widest text-theme-muted mb-2">
            Feed Views
          </p>

          <button
            onClick={() => {
              setActiveFilter('all');
              setActiveFolder('all');
            }}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-serif font-semibold transition-all min-h-[40px] ${
              activeFilter === 'all' && activeFolder === 'all'
                ? 'bg-amber-500/15 border border-amber-500/30 text-theme-heading font-bold'
                : 'text-theme-muted hover:text-theme-heading hover:bg-theme-elevated/70'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Inbox className="h-4 w-4 text-amber-500" />
              <span>All Articles</span>
            </div>
            <span className="font-mono text-[10px] text-theme-muted">{articles.length}</span>
          </button>

          <button
            onClick={() => setActiveFilter('unread')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-serif font-semibold transition-all min-h-[40px] ${
              activeFilter === 'unread'
                ? 'bg-amber-500/15 border border-amber-500/30 text-theme-heading font-bold'
                : 'text-theme-muted hover:text-theme-heading hover:bg-theme-elevated/70'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <span className="h-2 w-2 rounded-full bg-amber-500" />
              <span>Unread</span>
            </div>
            {unreadTotal > 0 && (
              <Badge variant="amber" className="text-[10px] py-0 px-1.5 font-mono">
                {unreadTotal}
              </Badge>
            )}
          </button>

          <button
            onClick={() => setActiveFilter('bookmarks')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-serif font-semibold transition-all min-h-[40px] ${
              activeFilter === 'bookmarks'
                ? 'bg-amber-500/15 border border-amber-500/30 text-theme-heading font-bold'
                : 'text-theme-muted hover:text-theme-heading hover:bg-theme-elevated/70'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Bookmark className="h-4 w-4 text-amber-500" />
              <span>Saved Clippings</span>
            </div>
            <span className="font-mono text-[10px] text-theme-muted">
              {articles.filter((a) => a.isBookmarked).length}
            </span>
          </button>

          {/* Anonymous Discovery Trigger */}
          <button
            onClick={onOpenDiscovery}
            className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-serif font-semibold transition-all min-h-[40px] text-theme-muted hover:text-theme-heading hover:bg-theme-elevated/70 group"
          >
            <div className="flex items-center gap-2.5">
              <Compass className="h-4 w-4 text-amber-500" />
              <span>Discover Blogs</span>
            </div>
            <Badge variant="amber" className="text-[10px] py-0 px-1.5 font-mono">
              Auto
            </Badge>
          </button>

          {/* OPML Subscriptions Tool */}
          <button
            onClick={onOpenOPML}
            className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-serif font-semibold transition-all min-h-[40px] text-theme-muted hover:text-theme-heading hover:bg-theme-elevated/70 group"
          >
            <div className="flex items-center gap-2.5">
              <FileCode className="h-4 w-4 text-amber-500" />
              <span>OPML Export/Import</span>
            </div>
          </button>
        </div>

        {/* Folders & Feeds Tree */}
        <div className="space-y-3 pt-3 border-t border-theme-subtle">
          <div className="flex items-center justify-between px-3">
            <p className="text-[10px] font-mono font-bold uppercase tracking-widest text-theme-muted">
              Subscriptions ({feeds.length})
            </p>
            <button
              onClick={onOpenAddFeed}
              className="p-1 text-theme-muted hover:text-amber-500 transition-colors"
              title="Add blog feed"
            >
              <Plus className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="space-y-2">
            {folders.map((folder) => {
              const folderFeeds = feeds.filter((f) => (f.folder || 'General') === folder.name);
              const isExpanded = expandedFolders[folder.name] ?? true;
              const isFolderActive = activeFolder === folder.name;

              return (
                <div key={folder.id} className="space-y-1">
                  <div
                    onClick={() => {
                      setActiveFolder(isFolderActive ? 'all' : folder.name);
                      setActiveFilter('all');
                    }}
                    className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-serif cursor-pointer transition-colors ${
                      isFolderActive
                        ? 'bg-amber-500/10 text-amber-500 font-bold'
                        : 'text-theme-muted hover:text-theme-heading hover:bg-theme-elevated/50'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 truncate">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleFolder(folder.name);
                        }}
                        className="p-0.5 text-theme-muted hover:text-theme-heading"
                      >
                        {isExpanded ? (
                          <ChevronDown className="h-3.5 w-3.5" />
                        ) : (
                          <ChevronRight className="h-3.5 w-3.5" />
                        )}
                      </button>
                      <FolderIcon className="h-3.5 w-3.5 text-amber-500/80 shrink-0" />
                      <span className="truncate">{folder.name}</span>
                    </div>
                    <span className="text-[10px] text-theme-muted font-mono">{folderFeeds.length}</span>
                  </div>

                  {isExpanded && (
                    <div className="pl-6 space-y-0.5 border-l border-theme-subtle ml-3">
                      {folderFeeds.map((feed) => {
                        const isFeedActive = activeFilter === feed.id;
                        const feedUnread = articles.filter(
                          (a) => a.feedId === feed.id && !a.isRead
                        ).length;

                        return (
                          <div
                            key={feed.id}
                            onClick={() => {
                              setActiveFilter(feed.id);
                              setActiveFolder('all');
                            }}
                            className={`group flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-serif cursor-pointer transition-colors ${
                              isFeedActive
                                ? 'bg-amber-500/20 text-amber-500 font-bold'
                                : 'text-theme-muted hover:text-theme-heading hover:bg-theme-elevated/40'
                            }`}
                          >
                            <div className="flex items-center gap-2 truncate pr-2">
                              {feed.iconUrl ? (
                                <img
                                  src={feed.iconUrl}
                                  alt=""
                                  className="h-3.5 w-3.5 rounded shrink-0 object-contain"
                                  onError={(e) => {
                                    (e.target as HTMLElement).style.display = 'none';
                                  }}
                                />
                              ) : (
                                <Rss className="h-3.5 w-3.5 text-amber-500/70 shrink-0" />
                              )}
                              <span className="truncate">{feed.title}</span>
                            </div>

                            <div className="flex items-center gap-1 shrink-0">
                              {feedUnread > 0 && (
                                <span className="text-[10px] px-1.5 py-0.2 rounded bg-theme-elevated text-theme-muted font-mono">
                                  {feedUnread}
                                </span>
                              )}
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (confirm(`Unsubscribe from ${feed.title}?`)) {
                                    deleteFeed(feed.id);
                                  }
                                }}
                                title="Unsubscribe"
                                className="opacity-0 group-hover:opacity-100 p-1 text-theme-muted hover:text-rose-500 transition-opacity"
                              >
                                <Trash2 className="h-3 w-3" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Footer Info */}
      <div className="pt-4 border-t border-theme-subtle text-[11px] text-theme-muted space-y-1 font-serif">
        <p className="font-bold text-theme-heading flex items-center gap-1.5">
          <Sparkles className="h-3 w-3 text-amber-500" />
          <span>PS-003 Small Web Reader</span>
        </p>
        <p className="text-[10px] leading-tight text-theme-muted">
          100% offline-first IndexedDB cache. Zero accounts, zero tracking.
        </p>
      </div>
    </aside>
  );
};
