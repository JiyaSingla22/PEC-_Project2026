import React, { createContext, useContext, useState, useEffect } from 'react';

export type ThemeMode = 'dark' | 'light' | 'sepia';

export interface ThemeConfig {
  id: ThemeMode;
  name: string;
  tagline: string;
  icon: string;
}

export const THEMES: ThemeConfig[] = [
  {
    id: 'dark',
    name: 'Midnight Edition',
    tagline: 'Deep slate ink & warm amber gold',
    icon: 'moon',
  },
  {
    id: 'light',
    name: 'Morning Paper',
    tagline: 'Crisp ivory broadsheet & charcoal print',
    icon: 'sun',
  },
  {
    id: 'sepia',
    name: 'Vintage Gazette',
    tagline: 'Warm antique parchment & espresso ink',
    icon: 'book',
  },
];

interface ThemeContextValue {
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  cycleTheme: () => void;
  activeThemeConfig: ThemeConfig;
}

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

const STORAGE_KEY = 'incogniread-theme-preference';

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem(STORAGE_KEY) as ThemeMode | null;
      if (saved && (saved === 'dark' || saved === 'light' || saved === 'sepia')) {
        return saved;
      }
      if (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) {
        return 'light';
      }
    }
    return 'dark';
  });

  const applyTheme = (mode: ThemeMode) => {
    const root = document.documentElement;
    root.setAttribute('data-theme', mode);

    // Maintain dark class for tailwind dark: variants when on dark mode
    if (mode === 'dark') {
      root.classList.add('dark');
      root.classList.remove('light', 'sepia');
    } else if (mode === 'light') {
      root.classList.remove('dark', 'sepia');
      root.classList.add('light');
    } else {
      root.classList.remove('dark', 'light');
      root.classList.add('sepia');
    }
  };

  useEffect(() => {
    applyTheme(theme);
    try {
      localStorage.setItem(STORAGE_KEY, theme);
    } catch {
      // LocalStorage might be disabled
    }
  }, [theme]);

  const setTheme = (newTheme: ThemeMode) => {
    setThemeState(newTheme);
  };

  const cycleTheme = () => {
    setThemeState((prev) => {
      if (prev === 'dark') return 'light';
      if (prev === 'light') return 'sepia';
      return 'dark';
    });
  };

  const activeThemeConfig = THEMES.find((t) => t.id === theme) || THEMES[0];

  return (
    <ThemeContext.Provider value={{ theme, setTheme, cycleTheme, activeThemeConfig }}>
      {children}
    </ThemeContext.Provider>
  );
};

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}
