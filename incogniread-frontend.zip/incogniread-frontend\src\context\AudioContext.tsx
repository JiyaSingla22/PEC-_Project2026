import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import { Article, AudioQueueItem, PlaybackState } from '../types';
import {
  getAudioQueueFromDB,
  addToAudioQueueInDB,
  removeFromAudioQueueInDB,
  savePlaybackProgressInDB,
  getPlaybackProgressFromDB,
} from '../lib/db';
import { generateId } from '../lib/utils';

interface AudioContextValue {
  currentArticle: Article | null;
  playbackState: PlaybackState;
  activeParagraphIndex: number;
  activeSentence: string;
  currentTime: number;
  duration: number;
  playbackRate: number;
  volume: number;
  isMuted: boolean;
  queue: AudioQueueItem[];
  availableVoices: SpeechSynthesisVoice[];
  selectedVoice: SpeechSynthesisVoice | null;
  playArticle: (article: Article, startParagraphIndex?: number) => void;
  togglePlayPause: () => void;
  pause: () => void;
  resume: () => void;
  stop: () => void;
  skip: (seconds: number) => void;
  nextParagraph: () => void;
  previousParagraph: () => void;
  seekToParagraph: (paragraphIndex: number) => void;
  seekToProgress: (ratio: number) => void;
  setPlaybackRate: (rate: number) => void;
  setVolume: (volume: number) => void;
  toggleMute: () => void;
  setSelectedVoice: (voice: SpeechSynthesisVoice) => void;
  addToQueue: (article: Article) => Promise<void>;
  removeFromQueue: (itemId: string) => Promise<void>;
  playNextInQueue: () => void;
}

const AudioContext = createContext<AudioContextValue | undefined>(undefined);

export const AudioProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentArticle, setCurrentArticle] = useState<Article | null>(null);
  const [playbackState, setPlaybackState] = useState<PlaybackState>('idle');
  const [activeParagraphIndex, setActiveParagraphIndex] = useState<number>(0);
  const [activeSentence, setActiveSentence] = useState<string>('');
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [playbackRate, setRate] = useState<number>(1.0);
  const [volume, setVol] = useState<number>(1.0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [queue, setQueue] = useState<AudioQueueItem[]>([]);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoice, setSelectedVoiceState] = useState<SpeechSynthesisVoice | null>(null);

  // References to guarantee zero stale-closure issues during asynchronous Web Speech calls
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const timerIntervalRef = useRef<any>(null);
  const currentParagraphIndexRef = useRef<number>(0);
  const currentParagraphsRef = useRef<string[]>([]);
  const playbackRateRef = useRef<number>(1.0);
  const volumeRef = useRef<number>(1.0);
  const isMutedRef = useRef<boolean>(false);
  const previousVolumeRef = useRef<number>(1.0);
  const selectedVoiceRef = useRef<SpeechSynthesisVoice | null>(null);
  const currentArticleRef = useRef<Article | null>(null);
  currentArticleRef.current = currentArticle;

  // Initialize SpeechSynthesis and load offline queue from IndexedDB
  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      synthRef.current = window.speechSynthesis;

      const updateVoices = () => {
        const voices = synthRef.current?.getVoices() || [];
        setAvailableVoices(voices);

        // Prefer high quality English voices
        const defaultVoice =
          voices.find((v) => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Neural') || v.name.includes('Premium'))) ||
          voices.find((v) => v.lang.startsWith('en')) ||
          voices[0];

        if (defaultVoice) {
          selectedVoiceRef.current = defaultVoice;
          setSelectedVoiceState(defaultVoice);
        }
      };

      updateVoices();
      if (synthRef.current?.onvoiceschanged !== undefined) {
        synthRef.current.onvoiceschanged = updateVoices;
      }
    }

    // Load persistent offline audio queue
    getAudioQueueFromDB()
      .then(setQueue)
      .catch((err) => console.warn('[AudioContext] Could not load offline audio queue:', err));

    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      synthRef.current?.cancel();
    };
  }, []);

  // Periodic persistence of playback progress to IndexedDB
  useEffect(() => {
    if (!currentArticle || playbackState === 'idle') return;

    const interval = setInterval(() => {
      if (currentTime > 0 && duration > 0) {
        savePlaybackProgressInDB(currentArticle.id, currentTime, duration).catch(() => {});
      }
    }, 4000);

    return () => clearInterval(interval);
  }, [currentArticle, currentTime, duration, playbackState]);

  // Plays a specific paragraph in sequence with explicit options or fallback to refs
  const speakParagraph = useCallback(
    (
      paragraphs: string[],
      index: number,
      options?: { rate?: number; volume?: number; isMuted?: boolean }
    ) => {
      if (!synthRef.current || index >= paragraphs.length) {
        setPlaybackState('ended');
        setActiveSentence('');
        if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
        return;
      }

      currentParagraphsRef.current = paragraphs;
      currentParagraphIndexRef.current = index;
      setActiveParagraphIndex(index);

      const paragraphText = paragraphs[index];
      const utterance = new SpeechSynthesisUtterance(paragraphText);
      utteranceRef.current = utterance;

      if (selectedVoiceRef.current) {
        utterance.voice = selectedVoiceRef.current;
      }

      const effectiveRate = options?.rate ?? playbackRateRef.current;
      const effectiveIsMuted = options?.isMuted ?? isMutedRef.current;
      const effectiveVolume = effectiveIsMuted ? 0 : (options?.volume ?? volumeRef.current);

      utterance.rate = Math.max(0.5, Math.min(3.0, effectiveRate));
      utterance.volume = Math.max(0, Math.min(1.0, effectiveVolume));

      // Real-time boundary tracking for sentence synchronization
      utterance.onboundary = (event) => {
        if (event.name === 'sentence' || event.name === 'word') {
          const charIndex = event.charIndex;
          const sentenceChunk = paragraphText.substring(charIndex, charIndex + 50);
          setActiveSentence(sentenceChunk);
        }
      };

      utterance.onend = () => {
        // Automatically speak next paragraph
        if (currentParagraphIndexRef.current + 1 < paragraphs.length) {
          speakParagraph(paragraphs, currentParagraphIndexRef.current + 1);
        } else {
          setPlaybackState('ended');
          playNextInQueue();
        }
      };

      utterance.onerror = (err) => {
        if (err.error !== 'canceled' && err.error !== 'interrupted') {
          console.warn('[AudioContext] Utterance error:', err.error);
        }
      };

      // Ensure prior utterances are canceled and audio device buffer is clean
      setTimeout(() => {
        if (synthRef.current) {
          synthRef.current.speak(utterance);
        }
      }, 40);
    },
    []
  );

  const playArticle = useCallback(
    async (article: Article, startParagraphIndex = 0) => {
      if (!synthRef.current) {
        alert('Web Speech API is not supported in this browser.');
        return;
      }

      // Stop existing speech
      synthRef.current.cancel();
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);

      setCurrentArticle(article);
      setPlaybackState('playing');

      const currentRate = playbackRateRef.current;
      // Estimate duration (words / 150 wpm * 60 seconds)
      const totalWords = article.paragraphs.join(' ').split(/\s+/).length;
      const estimatedDurationSeconds = Math.max(30, Math.round((totalWords / (150 * currentRate)) * 60));
      setDuration(estimatedDurationSeconds);

      // Check saved progress in IndexedDB
      const savedPosition = await getPlaybackProgressFromDB(article.id);
      if (savedPosition && startParagraphIndex === 0) {
        setCurrentTime(savedPosition);
      } else {
        const paragraphRatio = article.paragraphs.length > 0 ? startParagraphIndex / article.paragraphs.length : 0;
        setCurrentTime(Math.round(paragraphRatio * estimatedDurationSeconds));
      }

      // Start tick timer
      timerIntervalRef.current = setInterval(() => {
        setCurrentTime((prev) => Math.min(prev + 1, estimatedDurationSeconds));
      }, 1000);

      const paragraphsToSpeak =
        article.paragraphs.length > 0 ? article.paragraphs : [article.title, article.excerpt];

      speakParagraph(paragraphsToSpeak, startParagraphIndex);
    },
    [speakParagraph]
  );

  const pause = useCallback(() => {
    if (synthRef.current) {
      synthRef.current.pause();
      setPlaybackState('paused');
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    }
  }, []);

  const resume = useCallback(() => {
    if (synthRef.current && synthRef.current.paused) {
      synthRef.current.resume();
      setPlaybackState('playing');
      timerIntervalRef.current = setInterval(() => {
        setCurrentTime((prev) => Math.min(prev + 1, duration));
      }, 1000);
    } else if (currentArticleRef.current) {
      // Chrome Windows resume workaround: if not resumed within 100ms, cleanly re-speak
      const paragraphs = currentArticleRef.current.paragraphs.length > 0
        ? currentArticleRef.current.paragraphs
        : [currentArticleRef.current.title, currentArticleRef.current.excerpt];
      playArticle(currentArticleRef.current, currentParagraphIndexRef.current);
    }
  }, [duration, playArticle]);

  const togglePlayPause = useCallback(() => {
    if (playbackState === 'playing') {
      pause();
    } else {
      resume();
    }
  }, [playbackState, pause, resume]);

  const stop = useCallback(() => {
    if (synthRef.current) {
      synthRef.current.cancel();
    }
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    setPlaybackState('idle');
    setActiveSentence('');
    setCurrentTime(0);
  }, []);

  const seekToParagraph = useCallback(
    (paragraphIndex: number) => {
      if (!currentArticleRef.current) return;
      const paragraphs = currentArticleRef.current.paragraphs.length > 0
        ? currentArticleRef.current.paragraphs
        : [currentArticleRef.current.title, currentArticleRef.current.excerpt];

      const safeIndex = Math.max(0, Math.min(paragraphIndex, paragraphs.length - 1));
      synthRef.current?.cancel();

      const progressFraction = safeIndex / Math.max(1, paragraphs.length);
      setCurrentTime(Math.round(progressFraction * duration));
      setPlaybackState('playing');

      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = setInterval(() => {
        setCurrentTime((prev) => Math.min(prev + 1, duration));
      }, 1000);

      speakParagraph(paragraphs, safeIndex);
    },
    [duration, speakParagraph]
  );

  const nextParagraph = useCallback(() => {
    if (!currentArticleRef.current) return;
    seekToParagraph(currentParagraphIndexRef.current + 1);
  }, [seekToParagraph]);

  const previousParagraph = useCallback(() => {
    if (!currentArticleRef.current) return;
    seekToParagraph(Math.max(0, currentParagraphIndexRef.current - 1));
  }, [seekToParagraph]);

  const skip = useCallback(
    (secondsDelta: number) => {
      if (!currentArticleRef.current) return;
      const paragraphs = currentArticleRef.current.paragraphs;
      if (paragraphs.length === 0) return;

      const paragraphDelta = Math.sign(secondsDelta) * Math.max(1, Math.round(Math.abs(secondsDelta) / 18));
      const targetIndex = Math.max(0, Math.min(currentParagraphIndexRef.current + paragraphDelta, paragraphs.length - 1));

      seekToParagraph(targetIndex);
    },
    [seekToParagraph]
  );

  const seekToProgress = useCallback(
    (ratio: number) => {
      if (!currentArticleRef.current) return;
      const safeRatio = Math.max(0, Math.min(1, ratio));
      const targetSeconds = Math.round(safeRatio * duration);
      setCurrentTime(targetSeconds);

      const paragraphs = currentArticleRef.current.paragraphs.length > 0
        ? currentArticleRef.current.paragraphs
        : [currentArticleRef.current.title, currentArticleRef.current.excerpt];

      const targetIndex = Math.floor(safeRatio * paragraphs.length);
      seekToParagraph(targetIndex);
    },
    [duration, seekToParagraph]
  );

  // Speed Change: Updates ref + state + immediate restart of current utterance at new speed
  const setPlaybackRate = useCallback(
    (rate: number) => {
      const clampedRate = Math.max(0.5, Math.min(3.0, Number(rate.toFixed(2))));
      playbackRateRef.current = clampedRate;
      setRate(clampedRate);

      if (currentArticleRef.current) {
        const totalWords = currentArticleRef.current.paragraphs.join(' ').split(/\s+/).length;
        const newDuration = Math.max(30, Math.round((totalWords / (150 * clampedRate)) * 60));
        setDuration(newDuration);
      }

      // If speech is in progress, cancel and immediately re-speak with new speed
      if (synthRef.current && (synthRef.current.speaking || playbackState === 'playing') && currentArticleRef.current) {
        synthRef.current.cancel();
        const paras = currentArticleRef.current.paragraphs.length > 0
          ? currentArticleRef.current.paragraphs
          : [currentArticleRef.current.title, currentArticleRef.current.excerpt];
        speakParagraph(paras, currentParagraphIndexRef.current, { rate: clampedRate });
      }
    },
    [playbackState, speakParagraph]
  );

  // Volume Change: Updates ref + state + immediate volume re-application
  const setVolume = useCallback(
    (vol: number) => {
      const clamped = Math.max(0, Math.min(1.0, Number(vol.toFixed(2))));
      volumeRef.current = clamped;
      setVol(clamped);

      if (clamped === 0) {
        isMutedRef.current = true;
        setIsMuted(true);
      } else {
        previousVolumeRef.current = clamped;
        isMutedRef.current = false;
        setIsMuted(false);
      }

      if (synthRef.current && (synthRef.current.speaking || playbackState === 'playing') && currentArticleRef.current) {
        synthRef.current.cancel();
        const paras = currentArticleRef.current.paragraphs.length > 0
          ? currentArticleRef.current.paragraphs
          : [currentArticleRef.current.title, currentArticleRef.current.excerpt];
        speakParagraph(paras, currentParagraphIndexRef.current, { volume: clamped, isMuted: clamped === 0 });
      }
    },
    [playbackState, speakParagraph]
  );

  // Mute Toggle: Instantly silences or restores audio
  const toggleMute = useCallback(() => {
    if (isMutedRef.current) {
      // Unmuting
      isMutedRef.current = false;
      setIsMuted(false);
      const restored = previousVolumeRef.current > 0 ? previousVolumeRef.current : 1.0;
      volumeRef.current = restored;
      setVol(restored);

      if (synthRef.current && (synthRef.current.speaking || playbackState === 'playing') && currentArticleRef.current) {
        synthRef.current.cancel();
        const paras = currentArticleRef.current.paragraphs.length > 0
          ? currentArticleRef.current.paragraphs
          : [currentArticleRef.current.title, currentArticleRef.current.excerpt];
        speakParagraph(paras, currentParagraphIndexRef.current, { volume: restored, isMuted: false });
      }
    } else {
      // Muting
      previousVolumeRef.current = volumeRef.current > 0 ? volumeRef.current : 1.0;
      isMutedRef.current = true;
      setIsMuted(true);
      setVol(0);

      if (synthRef.current && (synthRef.current.speaking || playbackState === 'playing') && currentArticleRef.current) {
        synthRef.current.cancel();
        const paras = currentArticleRef.current.paragraphs.length > 0
          ? currentArticleRef.current.paragraphs
          : [currentArticleRef.current.title, currentArticleRef.current.excerpt];
        // Speaks with volume 0 to preserve paragraph sync in pure silence
        speakParagraph(paras, currentParagraphIndexRef.current, { volume: 0, isMuted: true });
      }
    }
  }, [playbackState, speakParagraph]);

  const setSelectedVoice = (voice: SpeechSynthesisVoice) => {
    selectedVoiceRef.current = voice;
    setSelectedVoiceState(voice);
  };

  const addToQueue = async (article: Article) => {
    const queueItem: AudioQueueItem = {
      id: generateId('queue'),
      articleId: article.id,
      title: article.title,
      feedTitle: article.feedTitle,
      excerpt: article.excerpt,
      estimatedReadMinutes: article.estimatedReadMinutes,
      currentPositionSeconds: 0,
      dateAdded: new Date().toISOString(),
    };

    setQueue((prev) => [...prev, queueItem]);
    await addToAudioQueueInDB(queueItem);
  };

  const removeFromQueue = async (itemId: string) => {
    setQueue((prev) => prev.filter((item) => item.id !== itemId));
    await removeFromAudioQueueInDB(itemId);
  };

  const playNextInQueue = useCallback(() => {
    if (queue.length === 0) return;
    const [nextItem, ...remaining] = queue;
    setQueue(remaining);
    removeFromAudioQueueInDB(nextItem.id);
  }, [queue]);

  // Global Keyboard Shortcuts (Space for Play/Pause, M for Mute)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT' ||
          target.isContentEditable)
      ) {
        return;
      }

      if (e.code === 'Space' && currentArticleRef.current && playbackState !== 'idle') {
        e.preventDefault();
        togglePlayPause();
      } else if ((e.key === 'm' || e.key === 'M') && currentArticleRef.current && playbackState !== 'idle') {
        e.preventDefault();
        toggleMute();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [playbackState, togglePlayPause, toggleMute]);

  return (
    <AudioContext.Provider
      value={{
        currentArticle,
        playbackState,
        activeParagraphIndex,
        activeSentence,
        currentTime,
        duration,
        playbackRate,
        volume,
        isMuted,
        queue,
        availableVoices,
        selectedVoice,
        playArticle,
        togglePlayPause,
        pause,
        resume,
        stop,
        skip,
        nextParagraph,
        previousParagraph,
        seekToParagraph,
        seekToProgress,
        setPlaybackRate,
        setVolume,
        toggleMute,
        setSelectedVoice,
        addToQueue,
        removeFromQueue,
        playNextInQueue,
      }}
    >
      {children}
    </AudioContext.Provider>
  );
};

export function useAudio() {
  const context = useContext(AudioContext);
  if (!context) {
    throw new Error('useAudio must be used within an AudioProvider');
  }
  return context;
}
