import React from 'react';
import { Sheet } from '../ui/sheet';
import { useFeeds } from '../../context/FeedContext';
import { ThemeToggle } from '../ui/ThemeToggle';
import { IncogniReadLogo } from '../ui/IncogniReadLogo';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import {
  Rss,
  Folder as FolderIcon,
  Inbox,
  Bookmark,
  Compass,
  Plus,
  RefreshCw,
  FileCode,
} from 'lucide-react';

export interface MobileNavProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenAddFeed: () => void;
  onOpenDiscovery: () => void;
  onOpenOPML: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  isOpen,
  onClose,
  onOpenAddFeed,
  onOpenDiscovery,
  onOpenOPML,
}) => {
  const {
    feeds,
    articles,
    folders,
    activeFilter,
    activeFolder,
    setActiveFilter,
    setActiveFolder,
    syncAllFeeds,
    isSyncing,
  } = useFeeds();

  const unreadTotal = articles.filter((a) => !a.isRead).length;

  const handleSelectFilter = (filter: string, folder = 'all') => {
    setActiveFilter(filter);
    setActiveFolder(folder);
    onClose();
  };

  return (
    <Sheet
      isOpen={isOpen}
      onClose={onClose}
      side="left"
      title={
        <div className="flex items-center gap-2.5">
          <IncogniReadLogo size={28} />
          <span className="font-editorial font-bold text-base text-theme-heading">IncogniRead</span>
        </div>
      }
    >
      <div className="flex flex-col space-y-5">
        {/* Theme Switcher inside Mobile Drawer */}
        <div className="p-3 rounded-2xl border border-theme-border bg-theme-surface flex items-center justify-between">
          <span className="text-xs font-serif font-bold text-theme-heading">Reading Edition:</span>
          <ThemeToggle variant="dropdown" />
        </div>

        {/* Discovery & OPML Quick Actions */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => {
              onClose();
              onOpenDiscovery();
            }}
            className="flex items-center justify-center gap-2 p-2.5 rounded-xl border border-amber-500/30 bg-amber-500/10 text-xs font-serif font-bold text-theme-heading hover:bg-amber-500/20 transition-colors min-h-[44px]"
          >
            <Compass className="h-4 w-4 text-amber-500" />
            <span>Discover</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onOpenOPML();
            }}
            className="flex items-center justify-center gap-2 p-2.5 rounded-xl border border-theme-border bg-theme-surface text-xs font-serif font-bold text-theme-heading hover:bg-theme-elevated transition-colors min-h-[44px]"
          >
            <FileCode className="h-4 w-4 text-amber-500" />
            <span>OPML Export</span>
          </button>
        </div>

        {/* Main Filters */}
        <div className="space-y-1">
          <button
            onClick={() => handleSelectFilter('all')}
            className={`w-full flex items-center justify-between p-3 rounded-xl text-xs font-serif font-semibold transition-colors min-h-[44px] ${
              activeFilter === 'all' && activeFolder === 'all'
                ? 'bg-amber-500/20 text-amber-600 dark:text-amber-300 font-bold border border-amber-500/30'
                : 'text-theme-muted hover:text-theme-heading hover:bg-theme-elevated/70'
            }`}
          >
            <div className="flex items-center gap-3">
              <Inbox className="h-4 w-4 text-amber-500" />
              <span>All Articles</span>
            </div>
            <span className="font-mono text-xs text-theme-muted">{articles.length}</span>
          </button>

          <button
            onClick={() => handleSelectFilter('unread')}
            className={`w-full flex items-center justify-between p-3 rounded-xl text-xs font-serif font-semibold transition-colors min-h-[44px] ${
              activeFilter === 'unread'
                ? 'bg-amber-500/20 text-amber-600 dark:text-amber-300 font-bold border border-amber-500/30'
                : 'text-theme-muted hover:text-theme-heading hover:bg-theme-elevated/70'
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="h-2 w-2 rounded-full bg-amber-500" />
              <span>Unread</span>
            </div>
            {unreadTotal > 0 && (
              <Badge variant="amber" className="text-xs font-mono">
                {unreadTotal}
              </Badge>
            )}
          </button>

          <button
            onClick={() => handleSelectFilter('bookmarks')}
            className={`w-full flex items-center justify-between p-3 rounded-xl text-xs font-serif font-semibold transition-colors min-h-[44px] ${
              activeFilter === 'bookmarks'
                ? 'bg-amber-500/20 text-amber-600 dark:text-amber-300 font-bold border border-amber-500/30'
                : 'text-theme-muted hover:text-theme-heading hover:bg-theme-elevated/70'
            }`}
          >
            <div className="flex items-center gap-3">
              <Bookmark className="h-4 w-4 text-amber-500" />
              <span>Saved Clippings</span>
            </div>
            <span className="font-mono text-xs text-theme-muted">
              {articles.filter((a) => a.isBookmarked).length}
            </span>
          </button>
        </div>

        {/* Folders & Feeds Tree */}
        <div className="space-y-3 pt-3 border-t border-theme-subtle">
          <p className="px-1 text-[10px] font-mono font-bold uppercase tracking-widest text-theme-muted">
            Subscriptions ({feeds.length})
          </p>

          <div className="space-y-1">
            {feeds.map((feed) => {
              const isFeedActive = activeFilter === feed.id;
              return (
                <button
                  key={feed.id}
                  onClick={() => handleSelectFilter(feed.id)}
                  className={`w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-serif transition-colors min-h-[44px] ${
                    isFeedActive
                      ? 'bg-amber-500/20 text-amber-600 dark:text-amber-300 font-bold'
                      : 'text-theme-muted hover:text-theme-heading hover:bg-theme-elevated/60'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate pr-2">
                    <Rss className="h-3.5 w-3.5 text-amber-500 shrink-0" />
                    <span className="truncate">{feed.title}</span>
                  </div>
                  <span className="text-[10px] text-theme-muted font-mono">
                    {feed.folder}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="pt-4 border-t border-theme-subtle space-y-2">
          <Button
            variant="amber"
            onClick={() => {
              onClose();
              onOpenAddFeed();
            }}
            className="w-full gap-2 min-h-[44px] font-serif font-bold text-xs"
          >
            <Plus className="h-4 w-4" />
            <span>Follow New Blog</span>
          </Button>

          <Button
            variant="outline"
            onClick={syncAllFeeds}
            isLoading={isSyncing}
            className="w-full gap-2 min-h-[44px] font-serif text-xs"
          >
            <RefreshCw className="h-4 w-4" />
            <span>Refresh All Feeds</span>
          </Button>
        </div>
      </div>
    </Sheet>
  );
};
