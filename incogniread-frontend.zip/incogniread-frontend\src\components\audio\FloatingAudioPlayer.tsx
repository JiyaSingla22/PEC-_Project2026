import React, { useState, useRef } from 'react';
import { useAudio } from '../../context/AudioContext';
import { useFeeds } from '../../context/FeedContext';
import { formatDuration } from '../../lib/utils';
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  Volume1,
  VolumeX,
  FastForward,
  ListMusic,
  X,
  Headphones,
  Maximize2,
  ChevronLeft,
  ChevronRight,
  Gauge,
  Sparkles,
  SlidersHorizontal,
} from 'lucide-react';

export const FloatingAudioPlayer: React.FC = () => {
  const {
    currentArticle,
    playbackState,
    currentTime,
    duration,
    playbackRate,
    volume,
    isMuted,
    queue,
    activeSentence,
    activeParagraphIndex,
    togglePlayPause,
    stop,
    skip,
    nextParagraph,
    previousParagraph,
    seekToProgress,
    setPlaybackRate,
    setVolume,
    toggleMute,
    playNextInQueue,
  } = useAudio();

  const { setReadingArticle } = useFeeds();

  const [isSpeedOpen, setIsSpeedOpen] = useState(false);
  const [isVolumeSliderOpen, setIsVolumeSliderOpen] = useState(false);
  const [isQueueOpen, setIsQueueOpen] = useState(false);
  const progressBarRef = useRef<HTMLDivElement>(null);

  if (!currentArticle || playbackState === 'idle') return null;

  const isPlaying = playbackState === 'playing';
  const progressPercent = duration > 0 ? Math.min(100, Math.max(0, (currentTime / duration) * 100)) : 0;
  const remainingSeconds = Math.max(0, duration - currentTime);

  const speedPresets = [
    { rate: 0.75, label: '0.75× Leisurely', desc: 'Slow & relaxed' },
    { rate: 1.0, label: '1.0× Normal', desc: 'Natural voice' },
    { rate: 1.25, label: '1.25× Brisk', desc: 'Editorial pace' },
    { rate: 1.5, label: '1.5× Swift', desc: 'Fast reader' },
    { rate: 1.75, label: '1.75× Rapid', desc: 'High tempo' },
    { rate: 2.0, label: '2.0× Double', desc: 'Maximum speed' },
  ];

  // 1-Click speed cycle
  const handleCycleSpeed = (e: React.MouseEvent) => {
    e.stopPropagation();
    const sequence = [1.0, 1.25, 1.5, 1.75, 2.0, 0.75];
    const currentIndex = sequence.indexOf(playbackRate);
    const nextRate = sequence[(currentIndex + 1) % sequence.length];
    setPlaybackRate(nextRate);
  };

  const handleProgressBarClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressBarRef.current || duration === 0) return;
    const rect = progressBarRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const ratio = Math.max(0, Math.min(1, clickX / rect.width));
    seekToProgress(ratio);
  };

  const getVolumeIcon = () => {
    if (isMuted || volume === 0) return <VolumeX className="h-4 w-4 text-rose-500" />;
    if (volume < 0.5) return <Volume1 className="h-4 w-4 text-theme-heading" />;
    return <Volume2 className="h-4 w-4 text-theme-heading" />;
  };

  return (
    <div className="fixed bottom-0 inset-x-0 z-40 p-2 sm:p-4 pointer-events-none animate-slide-up">
      <div className="max-w-4xl mx-auto pointer-events-auto rounded-2xl border-2 border-theme-border bg-theme-surface-solid shadow-2xl shadow-black/40 overflow-hidden transition-all duration-200">
        {/* Interactive High-Contrast Scrub Bar */}
        <div
          ref={progressBarRef}
          onClick={handleProgressBarClick}
          role="slider"
          aria-valuenow={Math.round(progressPercent)}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label="Audio scrubber"
          className="relative h-2.5 w-full bg-theme-elevated cursor-pointer group select-none"
        >
          {/* Progress fill */}
          <div
            className="h-full bg-amber-500 rounded-full transition-all duration-150 relative"
            style={{ width: `${progressPercent}%` }}
          >
            {/* Scrubber Knob */}
            <span className="absolute right-0 top-1/2 -translate-y-1/2 h-4 w-4 rounded-full bg-white shadow-md border-2 border-amber-600 scale-100 transition-transform -mr-2" />
          </div>
        </div>

        {/* Player Controls Inner Container */}
        <div className="px-4 py-3 flex flex-col sm:flex-row items-center justify-between gap-3 bg-theme-surface-solid">
          {/* Article Info & Live Spoken Sentence preview */}
          <div className="flex items-center gap-3 min-w-0 w-full sm:w-auto">
            <button
              onClick={() => setReadingArticle(currentArticle)}
              aria-label="Open Reader View"
              title="Open full editorial reader"
              className="relative flex h-12 w-12 items-center justify-center rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-500 shrink-0 hover:scale-105 transition-all shadow-xs"
            >
              {isPlaying ? (
                /* Equalizer animated wave bars */
                <div className="flex items-end justify-center gap-0.5 h-5 w-5">
                  <span className="w-1 bg-amber-500 rounded-full animate-equalizer-1" />
                  <span className="w-1 bg-amber-400 rounded-full animate-equalizer-2" />
                  <span className="w-1 bg-emerald-500 rounded-full animate-equalizer-3" />
                  <span className="w-1 bg-amber-500 rounded-full animate-equalizer-4" />
                </div>
              ) : (
                <Headphones className="h-5 w-5 text-amber-500" />
              )}
              {isPlaying && (
                <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
                </span>
              )}
            </button>

            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 font-mono">
                  {currentArticle.feedTitle}
                </span>
                <span className="text-theme-muted text-[10px]">•</span>
                <span className="text-[11px] font-bold text-theme-heading font-mono">
                  {formatDuration(currentTime)} / {formatDuration(duration)}
                </span>
                <span className="text-[10px] text-theme-muted font-mono hidden md:inline">
                  (-{formatDuration(remainingSeconds)})
                </span>
                {currentArticle.paragraphs.length > 0 && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-theme-elevated text-theme-heading font-mono font-semibold hidden lg:inline border border-theme-border">
                    Para {activeParagraphIndex + 1}/{currentArticle.paragraphs.length}
                  </span>
                )}
              </div>
              <h4
                onClick={() => setReadingArticle(currentArticle)}
                className="text-xs sm:text-sm font-editorial font-bold text-theme-heading truncate cursor-pointer hover:text-amber-600 dark:hover:text-amber-400 transition-colors pt-0.5"
                title={currentArticle.title}
              >
                {currentArticle.title}
              </h4>
              {/* Spoken subtitle snippet with elegant editorial quotation */}
              {activeSentence ? (
                <p className="text-[11px] text-amber-600 dark:text-amber-300 truncate font-serif italic hidden sm:block">
                  “{activeSentence}”
                </p>
              ) : (
                <p className="text-[10px] text-theme-muted truncate hidden sm:block font-serif">
                  Press Space to pause/resume • Press M to mute
                </p>
              )}
            </div>
          </div>

          {/* Primary Audio Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Previous Paragraph */}
            <button
              onClick={previousParagraph}
              aria-label="Previous paragraph"
              title="Previous paragraph"
              className="p-2 text-theme-muted hover:text-theme-heading rounded-xl hover:bg-theme-elevated transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center border border-theme-border/50"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>

            {/* Skip -10s */}
            <button
              onClick={() => skip(-10)}
              aria-label="Rewind 10 seconds"
              title="Rewind 10s"
              className="p-2 text-theme-muted hover:text-theme-heading rounded-xl hover:bg-theme-elevated transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center border border-theme-border/50"
            >
              <RotateCcw className="h-4 w-4" />
            </button>

            {/* Play / Pause Toggle Button */}
            <button
              onClick={togglePlayPause}
              aria-label={isPlaying ? 'Pause narration (Space)' : 'Resume narration (Space)'}
              title={isPlaying ? 'Pause narration (Space)' : 'Play narration (Space)'}
              className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black shadow-lg shadow-amber-500/30 transition-all duration-200 active:scale-95 hover:scale-105"
            >
              {isPlaying ? (
                <Pause className="h-5 w-5 fill-current" />
              ) : (
                <Play className="h-5 w-5 fill-current ml-0.5" />
              )}
            </button>

            {/* Skip +10s */}
            <button
              onClick={() => skip(10)}
              aria-label="Forward 10 seconds"
              title="Fast forward 10s"
              className="p-2 text-theme-muted hover:text-theme-heading rounded-xl hover:bg-theme-elevated transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center border border-theme-border/50"
            >
              <RotateCw className="h-4 w-4" />
            </button>

            {/* Next Paragraph */}
            <button
              onClick={nextParagraph}
              aria-label="Next paragraph"
              title="Next paragraph"
              className="p-2 text-theme-muted hover:text-theme-heading rounded-xl hover:bg-theme-elevated transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center border border-theme-border/50"
            >
              <ChevronRight className="h-4 w-4" />
            </button>

            {/* Speed Selector (1-Click Cycle + Dropdown Menu) */}
            <div className="relative">
              <button
                onClick={handleCycleSpeed}
                onContextMenu={(e) => {
                  e.preventDefault();
                  setIsSpeedOpen(!isSpeedOpen);
                }}
                aria-label={`Playback speed: ${playbackRate}x. Click to cycle, right-click for presets.`}
                title={`Speed: ${playbackRate}× — Click to cycle (${playbackRate === 2.0 ? '0.75×' : playbackRate + 0.25 + '×'})`}
                className="px-2.5 py-1 text-xs font-mono font-bold rounded-xl border-2 border-amber-500/40 bg-theme-surface hover:bg-amber-500/15 text-theme-heading transition-colors min-h-[40px] flex items-center gap-1 shadow-xs"
              >
                <Gauge className="h-3.5 w-3.5 text-amber-500" />
                <span className="text-amber-600 dark:text-amber-400">{playbackRate.toFixed(playbackRate % 1 === 0 ? 0 : 2)}×</span>
              </button>

              {/* Speed Mode Menu Button */}
              <button
                onClick={() => setIsSpeedOpen(!isSpeedOpen)}
                title="Open speed mode presets"
                className="absolute -top-1 -right-1 h-3.5 w-3.5 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center text-[8px] font-bold"
              >
                ▼
              </button>

              {isSpeedOpen && (
                <div className="absolute bottom-14 right-0 p-3 rounded-2xl bg-theme-surface-solid border-2 border-theme-border shadow-2xl flex flex-col gap-2 z-50 min-w-[220px] animate-slide-up backdrop-blur-xl">
                  <div className="flex items-center justify-between pb-1.5 border-b border-theme-subtle">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-theme-muted font-mono">
                      Narration Speed Mode
                    </span>
                    <span className="text-xs font-mono font-bold text-amber-500">
                      {playbackRate}×
                    </span>
                  </div>

                  {/* Preset Speed Mode Pills */}
                  <div className="space-y-1">
                    {speedPresets.map((preset) => {
                      const isSelected = playbackRate === preset.rate;
                      return (
                        <button
                          key={preset.rate}
                          onClick={() => {
                            setPlaybackRate(preset.rate);
                            setIsSpeedOpen(false);
                          }}
                          className={`w-full px-2.5 py-1.5 rounded-xl text-left flex items-center justify-between text-xs transition-colors ${
                            isSelected
                              ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
                              : 'text-theme-heading hover:bg-theme-elevated'
                          }`}
                        >
                          <span className="font-mono font-semibold">{preset.label}</span>
                          <span
                            className={`text-[10px] ${
                              isSelected ? 'text-slate-900/80 font-mono' : 'text-theme-muted font-mono'
                            }`}
                          >
                            {preset.desc}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Fine Step Adjuster Buttons */}
                  <div className="pt-2 border-t border-theme-subtle flex items-center justify-between text-xs font-mono">
                    <span className="text-[10px] text-theme-muted">Fine Step:</span>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setPlaybackRate(Math.max(0.5, Number((playbackRate - 0.1).toFixed(1))))}
                        className="px-2 py-0.5 rounded-lg border border-theme-border hover:bg-theme-elevated text-theme-heading font-bold"
                        title="Decrease by 0.1x"
                      >
                        -0.1
                      </button>
                      <button
                        onClick={() => setPlaybackRate(Math.min(3.0, Number((playbackRate + 0.1).toFixed(1))))}
                        className="px-2 py-0.5 rounded-lg border border-theme-border hover:bg-theme-elevated text-theme-heading font-bold"
                        title="Increase by 0.1x"
                      >
                        +0.1
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Instant Mute / Unmute Button with Popover Volume Slider */}
            <div
              className="relative"
              onMouseEnter={() => setIsVolumeSliderOpen(true)}
              onMouseLeave={() => setIsVolumeSliderOpen(false)}
            >
              <button
                onClick={toggleMute}
                aria-label={isMuted ? 'Unmute narration (M)' : 'Mute narration (M)'}
                title={isMuted ? 'Unmute narration (Press M)' : `Mute (Press M) • Vol ${Math.round((isMuted ? 0 : volume) * 100)}%`}
                className={`p-2 rounded-xl border-2 transition-all min-h-[40px] min-w-[40px] flex items-center justify-center ${
                  isMuted
                    ? 'bg-rose-500/20 text-rose-600 dark:text-rose-400 border-rose-500 shadow-sm'
                    : 'bg-theme-surface hover:bg-theme-elevated text-theme-heading border-theme-border'
                }`}
              >
                {getVolumeIcon()}
              </button>

              {/* Hover Volume Slider Flyout */}
              {isVolumeSliderOpen && (
                <div className="absolute bottom-12 left-1/2 -translate-x-1/2 p-3 rounded-2xl bg-theme-surface-solid border-2 border-theme-border shadow-2xl flex flex-col items-center gap-2 z-50 animate-slide-up backdrop-blur-xl min-w-[130px]">
                  <div className="flex items-center justify-between w-full text-[10px] font-mono font-bold">
                    <span className={isMuted ? 'text-rose-500 font-bold' : 'text-theme-heading'}>
                      {isMuted ? 'MUTED' : `VOL: ${Math.round(volume * 100)}%`}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={isMuted ? 0 : volume}
                    onChange={(e) => setVolume(parseFloat(e.target.value))}
                    className="w-24 h-2 accent-amber-500 cursor-pointer bg-theme-elevated rounded-lg"
                    aria-label="Volume slider"
                  />
                  <button
                    onClick={toggleMute}
                    className="text-[11px] font-serif font-bold text-amber-600 dark:text-amber-400 hover:underline pt-0.5"
                  >
                    {isMuted ? 'Click to Unmute' : 'Click to Mute'}
                  </button>
                </div>
              )}
            </div>

            {/* Queue Toggle Pill */}
            {queue.length > 0 && (
              <button
                onClick={() => setIsQueueOpen(!isQueueOpen)}
                className="relative p-2 text-theme-muted hover:text-theme-heading rounded-xl hover:bg-theme-elevated transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center border border-theme-border/50"
                title={`${queue.length} articles in audio queue`}
              >
                <ListMusic className="h-4 w-4" />
                <span className="absolute top-1 right-1 px-1 text-[9px] rounded-full bg-amber-500 text-slate-950 font-bold font-mono">
                  {queue.length}
                </span>
              </button>
            )}

            {/* Maximize to Reader View */}
            <button
              onClick={() => setReadingArticle(currentArticle)}
              aria-label="Open Reader View"
              title="Expand to full editorial reading format"
              className="p-2 text-theme-muted hover:text-theme-heading rounded-xl hover:bg-theme-elevated transition-colors hidden md:flex items-center justify-center min-h-[40px] min-w-[40px] border border-theme-border/50"
            >
              <Maximize2 className="h-4 w-4" />
            </button>

            {/* Close / Stop */}
            <button
              onClick={stop}
              aria-label="Close audio player"
              title="Stop audio player"
              className="p-2 text-theme-muted hover:text-theme-heading rounded-xl hover:bg-theme-elevated transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center border border-theme-border/50"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Dropdown Mini Queue Preview */}
        {isQueueOpen && queue.length > 0 && (
          <div className="px-4 py-3 border-t-2 border-theme-border bg-theme-surface-solid space-y-2 max-h-48 overflow-y-auto">
            <div className="flex items-center justify-between text-xs text-theme-muted font-serif font-bold uppercase tracking-wider">
              <span>Up Next in Audio Queue</span>
              <button onClick={playNextInQueue} className="text-amber-600 dark:text-amber-400 hover:underline text-[11px] font-mono">
                Skip to Next
              </button>
            </div>
            {queue.map((item, idx) => (
              <div
                key={item.id}
                className="flex items-center justify-between p-2 rounded-xl bg-theme-surface border border-theme-border text-xs"
              >
                <div className="truncate pr-2">
                  <span className="font-mono text-[10px] text-amber-500 mr-2">#{idx + 1}</span>
                  <span className="text-theme-heading font-serif font-medium">{item.title}</span>
                </div>
                <span className="text-[10px] text-theme-muted font-mono shrink-0">
                  {item.estimatedReadMinutes}m read
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
