import React, { useState, useEffect, useRef } from 'react';
import { useFeeds } from '../../context/FeedContext';
import { useAudio } from '../../context/AudioContext';
import { useTheme } from '../../context/ThemeContext';
import { ThemeToggle } from '../ui/ThemeToggle';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { timeAgo, formatDuration } from '../../lib/utils';
import {
  X,
  Play,
  Pause,
  Bookmark,
  ExternalLink,
  Clock,
  User,
  ShieldCheck,
  Headphones,
  Volume2,
  VolumeX,
  Gauge,
  Plus,
  ChevronLeft,
  ChevronRight,
  AlignLeft,
  Type,
  BookOpen,
} from 'lucide-react';

export const ReaderView: React.FC = () => {
  const { readingArticle, setReadingArticle, toggleBookmark, markAsRead } = useFeeds();
  const {
    currentArticle,
    playbackState,
    activeParagraphIndex,
    playbackRate,
    volume,
    isMuted,
    playArticle,
    togglePlayPause,
    seekToParagraph,
    nextParagraph,
    previousParagraph,
    setPlaybackRate,
    toggleMute,
    addToQueue,
  } = useAudio();

  const { theme } = useTheme();

  const [fontSize, setFontSize] = useState<'sm' | 'base' | 'lg' | 'xl'>('base');
  const [fontFamily, setFontFamily] = useState<'editorial' | 'serif' | 'sans' | 'mono'>('editorial');
  const [columnWidth, setColumnWidth] = useState<'normal' | 'wide' | 'narrow'>('normal');
  const [isSpeedOpen, setIsSpeedOpen] = useState(false);
  const activeParagraphRef = useRef<HTMLParagraphElement | null>(null);

  useEffect(() => {
    if (readingArticle) {
      markAsRead(readingArticle.id);
    }
  }, [readingArticle]);

  // Auto-scroll to active paragraph during narration
  useEffect(() => {
    if (
      currentArticle?.id === readingArticle?.id &&
      playbackState === 'playing' &&
      activeParagraphRef.current
    ) {
      activeParagraphRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [activeParagraphIndex, currentArticle?.id, readingArticle?.id, playbackState]);

  // Close reader on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && readingArticle) {
        setReadingArticle(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [readingArticle, setReadingArticle]);

  if (!readingArticle) return null;

  const isCurrentAudio = currentArticle?.id === readingArticle.id;
  const isAudioPlaying = isCurrentAudio && playbackState === 'playing';

  const fontClasses = {
    sm: 'text-sm sm:text-base leading-relaxed',
    base: 'text-base sm:text-lg leading-relaxed sm:leading-loose',
    lg: 'text-lg sm:text-xl leading-relaxed sm:leading-loose',
    xl: 'text-xl sm:text-2xl leading-relaxed sm:leading-loose',
  };

  const familyClasses = {
    editorial: 'font-serif font-normal',
    serif: 'font-serif font-normal',
    sans: 'font-sans font-normal',
    mono: 'font-mono text-sm leading-relaxed',
  };

  const columnClasses = {
    narrow: 'max-w-2xl',
    normal: 'max-w-3xl',
    wide: 'max-w-4xl',
  };

  const speedRates = [0.75, 1.0, 1.25, 1.5, 2.0];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-theme-base flex flex-col justify-between animate-fade-in transition-colors duration-200">
      {/* Sticky Top Reader Action Bar */}
      <header className="sticky top-0 z-30 w-full border-b border-theme-border bg-theme-surface-solid/90 backdrop-blur-xl px-4 sm:px-8 py-3 flex items-center justify-between gap-2 shadow-xs transition-colors">
        {/* Left: Close & Feed Kicker */}
        <div className="flex items-center gap-2.5 min-w-0">
          <button
            onClick={() => setReadingArticle(null)}
            aria-label="Close reader view"
            title="Close reader (Esc)"
            className="flex items-center gap-1.5 text-xs font-semibold text-theme-muted hover:text-theme-heading px-3 py-1.5 rounded-xl hover:bg-theme-elevated border border-theme-border transition-colors min-h-[40px] shrink-0"
          >
            <X className="h-4 w-4" />
            <span className="hidden sm:inline">Close</span>
          </button>

          <Badge variant="amber" className="gap-1 py-1 font-mono text-[11px] truncate max-w-[140px] sm:max-w-xs">
            <span>{readingArticle.feedTitle}</span>
          </Badge>

          <Badge variant="emerald" className="gap-1 py-1 text-[11px] hidden md:inline-flex">
            <ShieldCheck className="h-3.5 w-3.5" />
            <span>DOMPurify Safe</span>
          </Badge>
        </div>

        {/* Center/Right: Audio Bar & Typography & Theme Tools */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* TTS Listen / Pause Primary Button */}
          <Button
            variant={isAudioPlaying ? 'emerald' : 'amber'}
            size="sm"
            onClick={() => {
              if (isCurrentAudio) {
                togglePlayPause();
              } else {
                playArticle(readingArticle);
              }
            }}
            className="gap-2 shadow-md min-h-[40px] text-xs font-semibold px-3"
            title="Listen to this article with speech narration"
          >
            {isAudioPlaying ? (
              <>
                <div className="flex items-end justify-center gap-0.5 h-4 w-4">
                  <span className="w-0.5 bg-current rounded-full animate-equalizer-1" />
                  <span className="w-0.5 bg-current rounded-full animate-equalizer-2" />
                  <span className="w-0.5 bg-current rounded-full animate-equalizer-3" />
                </div>
                <span>Pause</span>
              </>
            ) : (
              <>
                <Headphones className="h-4 w-4" />
                <span className="hidden sm:inline">Listen Aloud</span>
              </>
            )}
          </Button>

          {/* Speed Selector in Reader Bar (when current audio is active) */}
          {isCurrentAudio && (
            <div className="relative">
              <button
                onClick={() => setIsSpeedOpen(!isSpeedOpen)}
                className="px-2 py-1 text-xs font-mono font-bold rounded-xl border border-theme-border bg-theme-surface hover:bg-theme-elevated text-theme-heading transition-colors min-h-[40px] flex items-center gap-1"
                title="Narration speed"
              >
                <Gauge className="h-3.5 w-3.5 text-amber-500" />
                <span>{playbackRate}×</span>
              </button>

              {isSpeedOpen && (
                <div className="absolute top-12 right-0 p-2 rounded-2xl bg-theme-surface-solid border border-theme-border shadow-2xl flex flex-col gap-1 z-50 min-w-[120px] animate-slide-up">
                  {speedRates.map((r) => (
                    <button
                      key={r}
                      onClick={() => {
                        setPlaybackRate(r);
                        setIsSpeedOpen(false);
                      }}
                      className={`px-3 py-1.5 text-xs rounded-xl font-mono text-left transition-colors ${
                        playbackRate === r
                          ? 'bg-amber-500 text-slate-950 font-bold'
                          : 'text-theme-body hover:bg-theme-elevated hover:text-theme-heading'
                      }`}
                    >
                      {r}× {r === 1.0 ? '(Normal)' : ''}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Mute Button in Reader Bar (when current audio is active) */}
          {isCurrentAudio && (
            <button
              onClick={toggleMute}
              title={isMuted ? 'Unmute narration (M)' : 'Mute narration (M)'}
              className={`p-2 rounded-xl border border-theme-border transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center ${
                isMuted
                  ? 'bg-rose-500/10 text-rose-500 border-rose-500/30'
                  : 'bg-theme-surface hover:bg-theme-elevated text-theme-heading'
              }`}
            >
              {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </button>
          )}

          {/* Add to Queue */}
          <button
            onClick={() => addToQueue(readingArticle)}
            title="Add to Audio Queue"
            className="p-2 text-theme-muted hover:text-theme-heading rounded-xl hover:bg-theme-elevated border border-theme-border transition-colors min-h-[40px] min-w-[40px] hidden sm:flex items-center justify-center"
          >
            <Plus className="h-4 w-4" />
          </button>

          {/* Bookmark Toggle */}
          <button
            onClick={() => toggleBookmark(readingArticle.id)}
            aria-label="Bookmark article"
            title={readingArticle.isBookmarked ? 'Remove Bookmark' : 'Bookmark this article'}
            className={`p-2 rounded-xl border border-theme-border transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center ${
              readingArticle.isBookmarked
                ? 'text-amber-500 bg-amber-500/10 border-amber-500/30'
                : 'text-theme-muted hover:text-theme-heading hover:bg-theme-elevated'
            }`}
          >
            <Bookmark className={`h-4 w-4 ${readingArticle.isBookmarked ? 'fill-current' : ''}`} />
          </button>

          {/* Font Type Switcher (Editorial Serif / Modern Sans / Mono) */}
          <button
            onClick={() => {
              const types: Array<'editorial' | 'sans' | 'mono'> = ['editorial', 'sans', 'mono'];
              const next = types[(types.indexOf(fontFamily as any) + 1) % types.length];
              setFontFamily(next);
            }}
            title={`Font: ${fontFamily} — Click to switch`}
            className="p-2 text-theme-muted hover:text-theme-heading rounded-xl hover:bg-theme-elevated border border-theme-border transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center font-editorial font-bold text-sm"
          >
            Aa
          </button>

          {/* Font Size Adjuster Cycle */}
          <button
            onClick={() => {
              const sizes: Array<'sm' | 'base' | 'lg' | 'xl'> = ['sm', 'base', 'lg', 'xl'];
              const next = sizes[(sizes.indexOf(fontSize) + 1) % sizes.length];
              setFontSize(next);
            }}
            title={`Font size: ${fontSize.toUpperCase()} — Click to cycle`}
            className="p-2 text-theme-muted hover:text-theme-heading rounded-xl hover:bg-theme-elevated border border-theme-border transition-colors min-h-[40px] min-w-[40px] hidden md:flex items-center justify-center font-mono text-xs font-semibold"
          >
            {fontSize === 'sm' ? 'A-' : fontSize === 'xl' ? 'A++' : fontSize === 'lg' ? 'A+' : 'A'}
          </button>

          {/* Theme Toggle Button */}
          <ThemeToggle variant="dropdown" />

          {/* Outbound Link to Publisher */}
          <a
            href={readingArticle.link}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="View original article on publisher site"
            title="Read on original publisher website"
            className="p-2 text-theme-muted hover:text-theme-heading rounded-xl hover:bg-theme-elevated border border-theme-border transition-colors min-h-[40px] min-w-[40px] hidden sm:flex items-center justify-center"
          >
            <ExternalLink className="h-4 w-4" />
          </a>
        </div>
      </header>

      {/* Reader Main Content Container (Classic Newspaper Editorial Format) */}
      <main className={`flex-1 mx-auto w-full px-5 sm:px-10 py-8 sm:py-14 transition-all duration-200 ${columnClasses[columnWidth]}`}>
        {/* Newspaper Editorial Header Masthead Deck */}
        <div className="space-y-4 pb-8 border-b-2 border-theme-rule/80">
          {/* Section Kicker */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-mono font-bold tracking-widest uppercase text-amber-600 dark:text-amber-400 text-[11px]">
                {readingArticle.feedTitle}
              </span>
              <span className="text-theme-muted">•</span>
              <span className="text-theme-muted flex items-center gap-1 font-serif">
                <Clock className="h-3.5 w-3.5" />
                {readingArticle.estimatedReadMinutes} min read ({timeAgo(readingArticle.publishedAt)})
              </span>
            </div>

            {readingArticle.author && (
              <span className="text-theme-muted flex items-center gap-1 font-serif italic text-xs">
                <User className="h-3.5 w-3.5 text-amber-500" />
                By {readingArticle.author}
              </span>
            )}
          </div>

          {/* Grand Newspaper Headline in Playfair Display / Editorial Serif */}
          <h1 className="text-3xl sm:text-5xl font-editorial font-bold text-theme-heading tracking-tight leading-[1.15]">
            {readingArticle.title}
          </h1>

          {/* Editorial Sub-deck / Excerpt in Italic Serif */}
          {readingArticle.excerpt && (
            <p className="text-base sm:text-xl font-serif italic text-theme-muted leading-relaxed pt-1 border-t border-theme-subtle">
              {readingArticle.excerpt}
            </p>
          )}

          {/* Active Audio Narration Banner */}
          {isCurrentAudio && (
            <div className="flex items-center justify-between p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-300 text-xs shadow-sm">
              <div className="flex items-center gap-2.5">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
                </span>
                <span className="font-serif font-semibold">
                  IncogniRead Audio Narration Active — Click any paragraph to jump speech instantly
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono opacity-90 hidden sm:inline">
                  Paragraph {activeParagraphIndex + 1} of {readingArticle.paragraphs.length}
                </span>
                <button
                  onClick={previousParagraph}
                  className="p-1 rounded hover:bg-amber-500/20"
                  title="Previous paragraph"
                >
                  <ChevronLeft className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={nextParagraph}
                  className="p-1 rounded hover:bg-amber-500/20"
                  title="Next paragraph"
                >
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Newspaper Editorial Article Body */}
        <article
          className={`pt-8 space-y-6 ${fontClasses[fontSize]} ${familyClasses[fontFamily]} text-theme-body`}
        >
          {readingArticle.paragraphs.length > 0 ? (
            readingArticle.paragraphs.map((para, index) => {
              const isActive = isCurrentAudio && activeParagraphIndex === index;
              const isFirst = index === 0;

              return (
                <p
                  key={index}
                  ref={isActive ? activeParagraphRef : null}
                  onClick={() => {
                    if (isCurrentAudio) {
                      seekToParagraph(index);
                    } else {
                      playArticle(readingArticle, index);
                    }
                  }}
                  className={`p-3.5 rounded-2xl transition-all duration-300 cursor-pointer ${
                    isFirst ? 'newspaper-drop-cap' : ''
                  } ${
                    isActive
                      ? 'bg-amber-500/15 border-l-4 border-amber-500 text-theme-heading shadow-md shadow-amber-500/10 scale-[1.01]'
                      : 'hover:bg-theme-elevated/50 border-l-4 border-transparent'
                  }`}
                  title="Click to jump audio narration here"
                >
                  {para}
                </p>
              );
            })
          ) : (
            // Raw Clean HTML Fallback
            <div
              className="prose prose-invert max-w-none text-theme-body"
              dangerouslySetInnerHTML={{ __html: readingArticle.contentClean }}
            />
          )}
        </article>

        {/* End of article newspaper colophon / footer */}
        <div className="mt-16 pt-8 border-t-2 border-theme-rule text-center space-y-4">
          <div className="flex items-center justify-center gap-3 text-amber-500 text-sm">
            <span>❖</span>
            <span>✦</span>
            <span>❖</span>
          </div>
          <p className="text-xs text-theme-muted font-serif italic">
            Printed from the IncogniRead Gazette • Cached offline in client IndexedDB • DOMPurify Protected
          </p>
          <div className="flex items-center justify-center gap-3 pt-2">
            <Button variant="outline" onClick={() => setReadingArticle(null)} className="font-serif">
              Return to Timeline
            </Button>
            <a
              href={readingArticle.link}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-theme-border bg-theme-surface hover:bg-theme-elevated text-xs font-serif font-semibold text-theme-heading transition-colors"
            >
              <span>Visit Original Publication</span>
              <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>
      </main>
    </div>
  );
};
