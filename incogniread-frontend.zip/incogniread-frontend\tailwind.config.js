/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ['class'],
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    screens: {
      'sm': '640px',
      'md': '768px',    // Tablet breakpoint
      'lg': '1024px',   // Desktop 3-column breakpoint
      'xl': '1280px',
      '2xl': '1536px',
    },
    extend: {
      fontFamily: {
        masthead: ['Cinzel', 'Playfair Display', 'serif'],
        editorial: ['"Playfair Display"', 'Newsreader', 'Georgia', 'serif'],
        serif: ['Newsreader', 'Georgia', 'Cambria', 'Times New Roman', 'serif'],
        sans: ['"Plus Jakarta Sans"', 'system-ui', '-apple-system', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      colors: {
        background: 'var(--bg-base)',
        surface: 'var(--bg-surface)',
        border: 'var(--border-color)',
        'theme-base': 'var(--bg-base)',
        'theme-surface': 'var(--bg-surface)',
        'theme-surface-solid': 'var(--bg-surface-solid)',
        'theme-elevated': 'var(--bg-elevated)',
        'theme-border': 'var(--border-color)',
        'theme-subtle': 'var(--border-subtle)',
        'theme-rule': 'var(--border-newspaper)',
        'theme-heading': 'var(--text-heading)',
        'theme-body': 'var(--text-body)',
        'theme-muted': 'var(--text-muted)',
        'theme-gold': 'var(--accent-gold)',
        'theme-audio': 'var(--accent-audio)',
        amber: {
          brand: '#f59e0b',
          glow: 'rgba(245, 158, 11, 0.25)',
        },
        emerald: {
          audio: '#10b981',
          glow: 'rgba(16, 185, 129, 0.25)',
        },
      },
      backdropBlur: {
        xs: '2px',
        xl: '20px',
        '2xl': '32px',
      },
      animation: {
        'pulse-subtle': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'slide-up': 'slideUp 0.25s cubic-bezier(0.16, 1, 0.3, 1)',
        'fade-in': 'fadeIn 0.2s ease-out',
        'equalizer-1': 'eq1 1s ease-in-out infinite alternate',
        'equalizer-2': 'eq2 0.8s ease-in-out infinite alternate 0.2s',
        'equalizer-3': 'eq3 1.2s ease-in-out infinite alternate 0.1s',
        'equalizer-4': 'eq4 0.9s ease-in-out infinite alternate 0.3s',
      },
      keyframes: {
        slideUp: {
          '0%': { transform: 'translateY(12px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        eq1: {
          '0%': { height: '4px' },
          '100%': { height: '16px' },
        },
        eq2: {
          '0%': { height: '14px' },
          '100%': { height: '6px' },
        },
        eq3: {
          '0%': { height: '6px' },
          '100%': { height: '18px' },
        },
        eq4: {
          '0%': { height: '12px' },
          '100%': { height: '4px' },
        },
      },
    },
  },
  plugins: [],
};
