import React, { useState, useRef, useEffect } from 'react';
import { useTheme, THEMES, ThemeMode } from '../../context/ThemeContext';
import { Moon, Sun, BookOpen, Check } from 'lucide-react';

export interface ThemeToggleProps {
  variant?: 'button' | 'dropdown';
  className?: string;
}

export const ThemeToggle: React.FC<ThemeToggleProps> = ({ variant = 'dropdown', className = '' }) => {
  const { theme, setTheme, cycleTheme, activeThemeConfig } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getThemeIcon = (mode: ThemeMode, sizeClass = 'h-4 w-4') => {
    switch (mode) {
      case 'light':
        return <Sun className={`${sizeClass} text-amber-600 dark:text-amber-400`} />;
      case 'sepia':
        return <BookOpen className={`${sizeClass} text-amber-700 dark:text-amber-300`} />;
      case 'dark':
      default:
        return <Moon className={`${sizeClass} text-amber-400`} />;
    }
  };

  if (variant === 'button') {
    return (
      <button
        onClick={cycleTheme}
        aria-label={`Toggle theme (Current: ${activeThemeConfig.name})`}
        title={`Theme: ${activeThemeConfig.name} — Click to cycle`}
        className={`relative flex items-center justify-center rounded-xl p-2.5 transition-all duration-200 border border-theme-border bg-theme-surface hover:bg-theme-elevated text-theme-heading shadow-sm min-h-[40px] min-w-[40px] ${className}`}
      >
        {getThemeIcon(theme)}
      </button>
    );
  }

  return (
    <div className={`relative ${className}`} ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        aria-label="Theme selection menu"
        title={`Theme: ${activeThemeConfig.name}`}
        className="flex items-center gap-2 px-3 py-2 rounded-xl border border-theme-border bg-theme-surface/80 hover:bg-theme-elevated text-theme-heading transition-all duration-200 text-xs font-serif font-medium shadow-sm min-h-[40px]"
      >
        {getThemeIcon(theme, 'h-3.5 w-3.5')}
        <span className="hidden sm:inline font-sans text-xs tracking-wide">{activeThemeConfig.name}</span>
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-56 rounded-2xl border border-theme-border bg-theme-surface-solid shadow-2xl p-1.5 z-50 animate-slide-up backdrop-blur-xl">
          <div className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-theme-muted font-mono border-b border-theme-subtle">
            Select Reading Edition
          </div>
          <div className="py-1 space-y-1">
            {THEMES.map((item) => {
              const isSelected = theme === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setTheme(item.id);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left transition-all ${
                    isSelected
                      ? 'bg-amber-500/15 border border-amber-500/30 text-theme-heading font-semibold shadow-xs'
                      : 'text-theme-body hover:bg-theme-elevated hover:text-theme-heading'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="p-1 rounded-lg bg-theme-elevated shrink-0">
                      {getThemeIcon(item.id, 'h-3.5 w-3.5')}
                    </div>
                    <div className="truncate">
                      <div className="text-xs font-serif font-bold text-theme-heading leading-tight">
                        {item.name}
                      </div>
                      <div className="text-[10px] text-theme-muted truncate font-sans">
                        {item.tagline}
                      </div>
                    </div>
                  </div>
                  {isSelected && <Check className="h-3.5 w-3.5 text-amber-500 shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
