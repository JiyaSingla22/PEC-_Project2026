# IncogniRead — Anonymous Discovery & Offline Reader for Independent Blogs
> **Submission for PS-003: Small Web Reader: Anonymous Discovery for Independent Blogs**  
> *"Follow blogs directly with no ranking, ads, or tracking. Discover new blogs through anonymous recommendations."*

IncogniRead is an offline-first, account-free web reader for independent blogs, RSS, and Atom feeds. It pairs an authentic broadsheet newspaper aesthetic (editorial serif typography, drop-caps, multi-column layout, and interactive magnifying glass lens) with a zero-telemetry co-subscription discovery engine.

---

## 🏛 1. Architecture Overview

IncogniRead is built as a single full-stack web application with two distinct decoupled layers:

```mermaid
flowchart TD
    subgraph Client["Client-Side Layer (100% In-Browser)"]
        UI["Web UI: Unified Timeline, Subscriptions, Reader View & Discover"]
        Parser["XML Parser (RSS 2.0 & Atom)"]
        Readability["Mozilla Readability-Style Extractor"]
        Sanitizer["DOMPurify HTML Whitelist Sanitizer"]
        IDB[("Persistent IndexedDB (Articles, Feeds & Read State)")]
        Audio["Web Speech TTS Audio Engine"]
        OPML["OPML 2.0 Import / Export Engine"]
    end

    subgraph Server["Server Layer (Same App)"]
        FetchRoute["GET /api/fetch (CORS Proxy & SSRF Defense)"]
        DiscoveryAPI["GET & POST /api/discovery (Co-Subscription Graph)"]
        IPHasher["Salted SHA-256 IP Hash Rate Limiter"]
    end

    subgraph ExternalWeb["Independent Web & Blogs"]
        Blogs["Independent Blogs, Atom Entries, RSS Feeds"]
    end

    UI --> IDB
    UI --> Audio
    UI --> OPML
    Parser --> FetchRoute
    FetchRoute -->|SSRF Check Passed| Blogs
    Blogs --> FetchRoute
    FetchRoute --> Parser
    Parser --> Readability
    Readability --> Sanitizer
    Sanitizer --> IDB
    UI --> DiscoveryAPI
    DiscoveryAPI --> IPHasher
```

### Layer Responsibilities
* **Client (Browser-First):**
  * All XML parsing, autodiscovery (`<link rel="alternate">`), full-text article extraction, HTML sanitization, and offline caching happen **strictly in the user's browser**.
  * No user accounts or login credentials exist. Subscriptions, read states, and clippings are stored locally in **IndexedDB**.
* **Server (Stateless & Unbiased):**
  * **Fetch Route (`/api/fetch`)**: Takes a `url` parameter and proxies the upstream feed or article to bypass browser CORS restrictions. **It does not parse, store, or log content.** Protected against Server-Side Request Forgery (SSRF).
  * **Discovery API (`/api/discovery`)**: An anonymous co-subscription engine that computes feed overlap clusters across readers without accounts, cookies, or tracking IDs.

---

## 🔒 2. Privacy & Threat Model

### What the Server Stores
* **Salted SHA-256 IP Hashes (Ephemeral):** When a client opts-in to submit an anonymous batch of feeds, the client IP is salted and hashed (`HMAC-SHA256(ip, salt)`). This hash is stored in memory solely to enforce rate limits (maximum 1 submission per 5 minutes per hash) and expires automatically.
* **Co-Subscription Graph Weights:** Undirected co-subscription edges between normalized feed URLs (e.g., `A::B -> weight`). No connection is ever recorded between a user's identity and any feed.

### What the Server NEVER Stores
* **No User Accounts:** No usernames, passwords, emails, or profile databases.
* **No Reading History:** The server has zero knowledge of which articles a user reads, bookmarks, or skips.
* **No Feed Content:** Upstream XML payloads are streamed through `/api/fetch` in memory and never persisted on disk.
* **No Raw IP Addresses:** Raw IP addresses are discarded immediately after computing the salted hash.

### Threat Model & Defenses
| Threat Vector | Defense Mechanism |
| :--- | :--- |
| **Server-Side Request Forgery (SSRF)** | Every URL requested via `/api/fetch` or submitted in `/api/discovery` is validated by `validateTargetUrl()`. Private IPv4 ranges (`10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`), loopback (`127.0.0.1`), link-local/cloud metadata (`169.254.169.254`), and IPv6 equivalents are strictly rejected. |
| **XSS via Proxied Feed Payloads** | All extracted HTML passes through `DOMPurify` before entering the DOM. Scripts, iframes, objects, forms, and inline event handlers (`onload`, `onerror`) are completely stripped. Outbound links are forced to `target="_blank" rel="noopener noreferrer nofollow"`. |
| **Sybil Telemetry Poisoning** | Co-subscription batch sizes are capped at 50 feeds. Submissions from the same salted IP hash are rate-limited to 1 per 5 minutes. Suspicious or duplicate batches are rejected. |
| **Memory Exhaustion / XML Bombs** | `/api/fetch` enforces a strict 6MB payload ceiling and a 10-second request timeout with `AbortController`. |

---

## ⚡ 3. Setup & Local Development

### Prerequisites
* Node.js v18+ or v20+
* npm or yarn

### Installation
```bash
# 1. Clone repository
git clone https://github.com/your-username/incogniread.git
cd incogniread

# 2. Install dependencies
npm install

# 3. Start development server
npm run dev
```

The application will be available at **`http://localhost:3002/`** (or `http://localhost:3001/`).

### Environment Variables (Optional)
Create a `.env` file in the root directory:
```env
# Salt used for one-way anonymized IP hashing in discovery rate-limiting
DISCOVERY_IP_SALT=your_secure_random_salt_here
```

---

## 🧪 4. Demo Instructions & Edge-Case Verification

IncogniRead includes a pre-populated dataset of high-quality independent blogs, along with resilience safeguards for evaluation:

### 1. Test Seed Blogs
* **Simon Willison’s Weblog:** `https://simonwillison.net/atom/entries/`
* **Overreacted (Dan Abramov):** `https://overreacted.io/rss.xml`
* **Julia Evans (Bite Size Networking):** `https://jvns.ca/atom.xml`
* **Antirez (Salvatore Sanfilippo):** `https://antirez.com/rss`
* **Mitchell Hashimoto:** `https://mitchellh.com/feed.xml`
* **Hacker News:** `https://news.ycombinator.com/rss`
* **404 Media:** `https://404media.co/rss/`

### 2. Edge-Case Scenarios
* **Dead / Offline Feed:** Enter an invalid domain (e.g. `https://nonexistent-domain-404-test.org/feed.xml`). The client-side parser catches the error, displays an informative non-blocking warning toast, and keeps the timeline intact.
* **Malformed XML:** If an upstream server returns invalid XML, the parser falls back gracefully without crashing the UI.
* **Duplicate URLs:** Subscribing to `https://simonwillison.net/atom/entries/` and `https://simonwillison.net/atom/entries` is automatically deduplicated via `normalizeFeedUrl()`.
* **No Feed Autodiscovery:** Enter a website URL like `https://overreacted.io`. The autodiscovery engine inspects the HTML `<link rel="alternate">` tag and discovers `https://overreacted.io/rss.xml`.

---

## 🏆 5. Bonus Points Implementation

1. **Bonus Quest: Deliberate Seed Trap Detection (+10 Extra Points):**
   * *Trap Identified:* The canonical duplication trap where `http://` and `https://` variants of the same publisher (or trailing slash variations) represent identical blogs.
   * *Resolution:* The built-in normalizer (`normalizeFeedUrl`) collapses protocols, removes `www`, strips query tracking, and strips trailing slashes, verified by the Trap Detection inspector in the Discover view.
2. **Transparent Recommendations:**
   * Every recommended blog clearly displays *why* it was suggested (e.g., *"Co-subscribed by 1,420 readers who also read Overreacted"*).
3. **"Blogs Like This" Interactive Graph View:**
   * An interactive network visualization showing clusters of connected blogs and co-subscription link weights.
4. **OPML 2.0 Import & Export:**
   * One-click download of all feeds into a standardized `.opml` file.
   * Full drag-and-drop or file upload parser to import OPML subscriptions from other readers.
5. **Web Speech TTS Audio Reader:**
   * Built-in narrator with real-time synchronized paragraph highlighting in broadsheet reading view, variable speed rates (0.75x–2.0x), true muting, and keyboard shortcuts (<kbd>Space</kbd> / <kbd>M</kbd>).
6. **3 Authentic Newspaper Editions:**
   * **Midnight Edition** (high-contrast dark mode)
   * **Morning Paper** (crisp high-contrast newsprint light mode)
   * **Vintage Gazette** (warm sepia broadsheet paper tone)
