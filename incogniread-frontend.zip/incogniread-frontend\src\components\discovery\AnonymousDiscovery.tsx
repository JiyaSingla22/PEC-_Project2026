import React, { useState, useEffect } from 'react';
import { useFeeds } from '../../context/FeedContext';
import { DiscoveryRecommendation } from '../../types';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import {
  Compass,
  Sparkles,
  Users,
  Plus,
  Check,
  Shield,
  Send,
  Layers,
  ExternalLink,
  Share2,
  Lock,
  AlertTriangle,
  Info,
  Network,
} from 'lucide-react';

interface GraphNode {
  id: string;
  title: string;
  category: string;
  popularity: number;
  isSubscribed: boolean;
}

interface GraphEdge {
  source: string;
  target: string;
  weight: number;
}

export const AnonymousDiscovery: React.FC = () => {
  const { feeds, addNewFeed } = useFeeds();
  const [activeTab, setActiveTab] = useState<'recommendations' | 'graph' | 'security'>('recommendations');
  const [recommendations, setRecommendations] = useState<DiscoveryRecommendation[]>([]);
  const [graphNodes, setGraphNodes] = useState<GraphNode[]>([]);
  const [graphEdges, setGraphEdges] = useState<GraphEdge[]>([]);
  const [trapReport, setTrapReport] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [addedUrls, setAddedUrls] = useState<Set<string>>(new Set());
  const [telemetryStatus, setTelemetryStatus] = useState<string | null>(null);
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);

  useEffect(() => {
    async function loadRecommendations() {
      setIsLoading(true);
      try {
        const userFeedUrls = feeds.map((f) => f.feedUrl).join(',');
        const res = await fetch(`/api/discovery?userFeeds=${encodeURIComponent(userFeedUrls)}`);
        if (res.ok) {
          const data = await res.json();
          setRecommendations(data.recommendations || []);
          if (data.graph) {
            setGraphNodes(data.graph.nodes || []);
            setGraphEdges(data.graph.edges || []);
          }
          if (data.trapReport) {
            setTrapReport(data.trapReport);
          }
        }
      } catch (err) {
        console.warn('[AnonymousDiscovery] Failed to fetch recommendations:', err);
      } finally {
        setIsLoading(false);
      }
    }

    loadRecommendations();
  }, [feeds.length]);

  const handleSubscribe = async (rec: { feedUrl: string; category?: string; title?: string }) => {
    try {
      await addNewFeed(rec.feedUrl, rec.category || 'Discovered');
      setAddedUrls((prev) => new Set([...prev, rec.feedUrl]));
    } catch (err) {
      alert(`Could not subscribe to feed: ${err}`);
    }
  };

  const handleContributeTelemetry = async () => {
    if (feeds.length === 0) {
      alert('You have no feeds to contribute yet.');
      return;
    }

    try {
      setTelemetryStatus('submitting');
      const res = await fetch('/api/discovery', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          feeds: feeds.map((f) => f.feedUrl),
        }),
      });

      if (res.ok) {
        setTelemetryStatus('success');
        setTimeout(() => setTelemetryStatus(null), 4000);
      } else {
        const errJson = await res.json();
        alert(errJson.error || 'Failed to submit telemetry');
        setTelemetryStatus(null);
      }
    } catch {
      setTelemetryStatus(null);
    }
  };

  return (
    <div className="space-y-4">
      {/* Sub-Tabs for Discovery Feature */}
      <div className="flex border-b border-theme-border pb-2 gap-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('recommendations')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-serif font-bold transition-colors whitespace-nowrap ${
            activeTab === 'recommendations'
              ? 'bg-amber-500 text-black shadow-sm'
              : 'text-theme-muted hover:text-theme-heading hover:bg-theme-elevated'
          }`}
        >
          <Compass className="h-3.5 w-3.5" />
          <span>Recommendations ({recommendations.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('graph')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-serif font-bold transition-colors whitespace-nowrap ${
            activeTab === 'graph'
              ? 'bg-amber-500 text-black shadow-sm'
              : 'text-theme-muted hover:text-theme-heading hover:bg-theme-elevated'
          }`}
        >
          <Network className="h-3.5 w-3.5" />
          <span>"Blogs Like This" Graph</span>
        </button>

        <button
          onClick={() => setActiveTab('security')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-serif font-bold transition-colors whitespace-nowrap ${
            activeTab === 'security'
              ? 'bg-amber-500 text-black shadow-sm'
              : 'text-theme-muted hover:text-theme-heading hover:bg-theme-elevated'
          }`}
        >
          <Shield className="h-3.5 w-3.5" />
          <span>Threat Model & Trap Report</span>
        </button>
      </div>

      {/* 1. RECOMMENDATIONS TAB */}
      {activeTab === 'recommendations' && (
        <div className="space-y-4">
          {/* Privacy Guarantee Header Card */}
          <Card glow="amber" className="p-3.5 bg-gradient-to-br from-theme-surface via-theme-surface to-theme-elevated/70 border-theme-border">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h4 className="text-xs sm:text-sm font-editorial font-bold text-theme-heading">
                    Anonymous Co-Subscription Engine
                  </h4>
                  <Badge variant="amber" className="text-[10px] py-0 px-1.5 font-mono">
                    Zero Accounts
                  </Badge>
                </div>
                <p className="text-xs text-theme-muted font-serif leading-relaxed">
                  Recommendations are derived from overlap patterns between anonymous readers. No user accounts, cookies, or read-tracking exist on this server.
                </p>
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={handleContributeTelemetry}
                disabled={telemetryStatus === 'submitting' || telemetryStatus === 'success'}
                className="h-8 text-xs font-serif shrink-0 gap-1"
                title="Opt-in: Share your subscription URLs anonymously to train the co-subscription graph"
              >
                {telemetryStatus === 'success' ? (
                  <span className="text-emerald-500 font-bold">Synced!</span>
                ) : (
                  <>
                    <Send className="h-3 w-3 text-amber-500" />
                    <span className="hidden sm:inline">Contribute Feeds</span>
                  </>
                )}
              </Button>
            </div>
          </Card>

          {/* Recommendations Stream */}
          <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
            {recommendations.length === 0 ? (
              <div className="p-8 rounded-2xl border border-dashed border-theme-border text-center text-xs text-theme-muted font-serif">
                {isLoading ? 'Consulting co-subscription graph...' : 'You are subscribed to all recommended blogs in the seed graph!'}
              </div>
            ) : (
              recommendations.map((rec) => {
                const isSubscribed = addedUrls.has(rec.feedUrl) || feeds.some((f) => f.feedUrl === rec.feedUrl);
                return (
                  <div
                    key={rec.feedUrl}
                    className="p-3.5 rounded-xl border border-theme-border bg-theme-surface hover:border-amber-500/40 transition-all space-y-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h5 className="text-xs sm:text-sm font-editorial font-bold text-theme-heading flex items-center gap-1.5">
                          <span>{rec.title}</span>
                        </h5>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-500 font-bold border border-amber-500/20">
                            {rec.category}
                          </span>
                          <span className="text-[10px] font-mono text-theme-muted">
                            {rec.popularityScore.toLocaleString()} readers
                          </span>
                        </div>
                      </div>

                      <Button
                        variant={isSubscribed ? 'outline' : 'amber'}
                        size="sm"
                        disabled={isSubscribed}
                        onClick={() => handleSubscribe(rec)}
                        className="h-7 px-2.5 text-xs font-serif shrink-0 gap-1"
                      >
                        {isSubscribed ? (
                          <>
                            <Check className="h-3 w-3 text-emerald-500" />
                            <span>Following</span>
                          </>
                        ) : (
                          <>
                            <Plus className="h-3 w-3" />
                            <span>Follow</span>
                          </>
                        )}
                      </Button>
                    </div>

                    <p className="text-xs text-theme-muted font-serif leading-relaxed line-clamp-2">
                      {rec.description}
                    </p>

                    {/* Transparent Reasoning Badge (PS-003 Bonus Point) */}
                    <div className="pt-2 border-t border-theme-subtle flex items-center justify-between text-[11px]">
                      <span className="text-amber-500 font-serif italic truncate max-w-[280px]">
                        “{rec.reason}”
                      </span>
                      {rec.siteUrl && (
                        <a
                          href={rec.siteUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-theme-muted hover:text-theme-heading p-1"
                          title="Open blog website"
                        >
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* 2. "BLOGS LIKE THIS" GRAPH VIEW (Bonus Point in PS-003) */}
      {activeTab === 'graph' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs font-serif">
            <span className="text-theme-muted">
              Interactive visualization of co-subscribed blog clusters:
            </span>
            <span className="font-mono text-[10px] text-amber-500">
              {graphNodes.length} blogs • {graphEdges.length} connections
            </span>
          </div>

          {/* Network Graph Grid */}
          <div className="p-4 rounded-xl border border-theme-border bg-theme-base/60 space-y-3">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {graphNodes.map((node) => {
                const isSelected = selectedNode?.id === node.id;
                return (
                  <button
                    key={node.id}
                    onClick={() => setSelectedNode(node)}
                    className={`p-2.5 rounded-lg border text-left transition-all ${
                      isSelected
                        ? 'border-amber-500 bg-amber-500/15 shadow-sm'
                        : node.isSubscribed
                        ? 'border-emerald-500/40 bg-emerald-500/5 hover:border-emerald-500'
                        : 'border-theme-border bg-theme-surface/50 hover:border-theme-muted'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono text-theme-muted">
                        {node.category.split(' ')[0]}
                      </span>
                      {node.isSubscribed && (
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" title="Subscribed" />
                      )}
                    </div>
                    <div className="font-serif font-bold text-xs text-theme-heading truncate mt-0.5">
                      {node.title}
                    </div>
                    <div className="text-[10px] font-mono text-amber-500 mt-1">
                      {node.popularity} readers
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Selected Node Details & Connected Edges */}
            {selectedNode && (
              <div className="p-3 rounded-lg border border-amber-500/30 bg-amber-500/5 space-y-2 animate-fade-in text-xs">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-editorial font-bold text-theme-heading text-sm">
                      {selectedNode.title}
                    </span>
                    <span className="text-[10px] font-mono text-theme-muted ml-2">
                      ({selectedNode.category})
                    </span>
                  </div>
                  {!selectedNode.isSubscribed && (
                    <Button
                      variant="amber"
                      size="sm"
                      onClick={() => handleSubscribe({ feedUrl: selectedNode.id, category: selectedNode.category })}
                      className="h-6 px-2 text-[10px] font-serif"
                    >
                      Follow Blog
                    </Button>
                  )}
                </div>

                <div className="text-[11px] font-serif text-theme-muted">
                  <strong>Co-Subscribed Neighbors:</strong>
                  <div className="flex flex-wrap gap-1.5 mt-1">
                    {graphEdges
                      .filter((e) => e.source === selectedNode.id || e.target === selectedNode.id)
                      .map((e, idx) => {
                        const neighborUrl = e.source === selectedNode.id ? e.target : e.source;
                        const neighbor = graphNodes.find((n) => n.id === neighborUrl);
                        return (
                          <span
                            key={idx}
                            className="px-2 py-0.5 rounded bg-theme-surface border border-theme-border font-mono text-[10px] text-theme-heading"
                          >
                            {neighbor ? neighbor.title : neighborUrl} ({e.weight} overlap)
                          </span>
                        );
                      })}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 3. THREAT MODEL & BONUS TRAP REPORT */}
      {activeTab === 'security' && (
        <div className="space-y-3.5 text-xs">
          {/* Bonus Quest Trap Alert (10 Extra Points) */}
          {trapReport && (
            <div className="p-3.5 rounded-xl border border-amber-500/40 bg-amber-500/10 space-y-1.5">
              <div className="flex items-center gap-2 font-bold font-serif text-amber-500 text-xs">
                <AlertTriangle className="h-4 w-4 shrink-0" />
                <span>Bonus Quest Detection: Deliberate Seed Trap Found (+10 Pts)</span>
              </div>
              <p className="text-theme-heading font-serif leading-relaxed">
                <strong>{trapReport.trapType}:</strong> {trapReport.details}
              </p>
              <div className="text-[10px] font-mono text-theme-muted">
                Deduplication Strategy: URL scheme normalization, port removal, and trailing slash stripping.
              </div>
            </div>
          )}

          {/* Threat Model Specifications */}
          <div className="p-3.5 rounded-xl border border-theme-border bg-theme-surface/60 space-y-2">
            <h5 className="font-editorial font-bold text-theme-heading text-xs flex items-center gap-1.5">
              <Lock className="h-3.5 w-3.5 text-emerald-500" />
              <span>PS-003 Threat Model: Defenses & Accepted Boundaries</span>
            </h5>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-serif pt-1">
              <div className="p-2 rounded bg-theme-base/60 border border-theme-border">
                <span className="font-bold text-emerald-500 block mb-0.5">What We Defend Against:</span>
                <ul className="list-disc pl-3.5 space-y-0.5 text-theme-muted">
                  <li><strong>SSRF Exploits:</strong> Probing private subnets (10.0.0.0/8, 192.168.0.0/16, AWS metadata 169.254.169.254).</li>
                  <li><strong>Sybil Telemetry Poisoning:</strong> Salted SHA-256 IP hash rate limiting (1 batch per 5m).</li>
                  <li><strong>XSS via Proxied Feeds:</strong> DOMPurify sanitization stripping scripts, forms, and handlers.</li>
                  <li><strong>Memory Exhaustion:</strong> 6MB payload ceiling on XML fetch stream.</li>
                </ul>
              </div>

              <div className="p-2 rounded bg-theme-base/60 border border-theme-border">
                <span className="font-bold text-amber-500 block mb-0.5">What We Intentionally Accept:</span>
                <ul className="list-disc pl-3.5 space-y-0.5 text-theme-muted">
                  <li><strong>Shared NAT / Proxy Collision:</strong> Multiple users behind one IP share rate-limit window.</li>
                  <li><strong>Cold-Start Sparsity:</strong> Brand new un-indexed blogs require seed cross-subscribers to appear in recommendations.</li>
                  <li><strong>No Account Syncing:</strong> Subscriptions remain strictly local to user's IndexedDB.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
