import React from 'react';

export interface IncogniReadLogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
  textClassName?: string;
}

export const IncogniReadLogo: React.FC<IncogniReadLogoProps> = ({
  className = 'h-9 w-9',
  size,
  showText = false,
  textClassName = '',
}) => {
  return (
    <div className="flex items-center gap-2.5 select-none">
      <div
        className={`relative flex items-center justify-center rounded-xl bg-gradient-to-br from-amber-500 via-amber-400 to-amber-600 shadow-md shadow-amber-500/25 text-slate-950 shrink-0 ${className}`}
        style={size ? { width: size, height: size } : undefined}
      >
        <svg
          viewBox="0 0 48 48"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full p-1.5"
        >
          {/* Incognito Fedora Hat Crown */}
          <path
            d="M13 18C14.5 12.5 19.5 11 24 13C28.5 11 33.5 12.5 35 18C31 18.8 17 18.8 13 18Z"
            fill="#090d16"
          />
          {/* Hat Ribbon Band (Warm Gold highlight) */}
          <path
            d="M13.8 17.5C18 16.5 30 16.5 34.2 17.5L34.6 18.8C30.5 18 17.5 18 13.4 18.8L13.8 17.5Z"
            fill="#f59e0b"
          />
          {/* Hat Brim (Curved classic silhouette) */}
          <path
            d="M8 21.5C14 18.5 34 18.5 40 21.5C35 23.5 13 23.5 8 21.5Z"
            fill="#090d16"
          />

          {/* Incognito Reading Spectacles */}
          {/* Left Lens */}
          <circle
            cx="17.5"
            cy="28"
            r="4.2"
            fill="#090d16"
            stroke="#090d16"
            strokeWidth="1.2"
          />
          <circle
            cx="17.5"
            cy="28"
            r="2.8"
            fill="#f59e0b"
            opacity="0.3"
          />
          {/* Right Lens */}
          <circle
            cx="30.5"
            cy="28"
            r="4.2"
            fill="#090d16"
            stroke="#090d16"
            strokeWidth="1.2"
          />
          <circle
            cx="30.5"
            cy="28"
            r="2.8"
            fill="#f59e0b"
            opacity="0.3"
          />
          {/* Spectacles Bridge */}
          <path
            d="M21.7 27C23 25.5 25 25.5 26.3 27"
            stroke="#090d16"
            strokeWidth="1.8"
            strokeLinecap="round"
          />
          {/* Spectacles Temple Wings */}
          <path
            d="M13.3 27.5L10 26.5"
            stroke="#090d16"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
          <path
            d="M34.7 27.5L38 26.5"
            stroke="#090d16"
            strokeWidth="1.5"
            strokeLinecap="round"
          />

          {/* Open Broadsheet / Newspaper Pages at base */}
          <path
            d="M10 36C15 34.2 21 34.6 24 37V41C21 38.6 15 38.2 10 40V36Z"
            fill="#090d16"
          />
          <path
            d="M38 36C33 34.2 27 34.6 24 37V41C27 38.6 33 38.2 38 40V36Z"
            fill="#090d16"
          />
          {/* Newspaper printed text lines */}
          <line x1="12" y1="36.5" x2="20" y2="35.5" stroke="#f59e0b" strokeWidth="1" strokeLinecap="round" />
          <line x1="12" y1="38.5" x2="18" y2="37.8" stroke="#f59e0b" strokeWidth="1" strokeLinecap="round" />
          <line x1="28" y1="35.5" x2="36" y2="36.5" stroke="#f59e0b" strokeWidth="1" strokeLinecap="round" />
          <line x1="30" y1="37.8" x2="36" y2="38.5" stroke="#f59e0b" strokeWidth="1" strokeLinecap="round" />

          {/* RSS Broadcast Signal Waves emanating top-right */}
          <path
            d="M35 11C37.5 12.5 39.5 15 40 18"
            stroke="#090d16"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
          <path
            d="M37.5 8C41 10 43.5 13.5 44 17.5"
            stroke="#090d16"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
          <circle cx="33" cy="13" r="1.2" fill="#090d16" />
        </svg>

        {/* Live Signal Pulse dot */}
        <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
        </span>
      </div>

      {showText && (
        <div>
          <span className={`font-editorial text-xl sm:text-2xl font-black tracking-tight text-theme-heading flex items-center gap-0.5 ${textClassName}`}>
            Incogni<span className="text-amber-500">Read</span>
            <span className="text-amber-500">.</span>
          </span>
          <p className="hidden sm:block text-[9px] text-theme-muted font-mono tracking-widest uppercase -mt-0.5">
            The Private Dispatch
          </p>
        </div>
      )}
    </div>
  );
};
